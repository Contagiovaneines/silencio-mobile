# Silêncio · beta 0.1

Jogo original de investigação e sobrevivência leve, feito primeiro para **Android em paisagem** com **Flutter + Flame**. O mundo é 2D com projeção isométrica. O projeto também tem destino web para revisão rápida no computador.

## Abrir no VS Code

Abra esta pasta inteira: `C:\Users\giovane\Desktop\editor\silencio`.

Com as extensões Dart e Flutter instaladas, selecione o celular na barra inferior e pressione **F5**. O caminho do Flutter disponível neste computador já está configurado em `.vscode/settings.json`.

Pelo terminal:

```powershell
flutter pub get
flutter run -d RQCX505FQMJ
```

Para testar no computador:

```powershell
flutter run -d chrome
```

## O que já existe

- Menu, cenário isométrico original de Santa Aurora e câmera que acompanha Caio.
- Caio animado com seus quadros de caminhada; Helena, Teresa e retratos do seu pacote. Inimigo com animação provisória.
- Movimento por controle virtual, toque no chão com busca de caminho e teclado.
- Colisão com edifícios e interação por proximidade com NPCs e objetos.
- Conversa com Helena e escolha de intenção; Caio se comunica pelo celular ou por escrita.
- Notícia em três páginas e faixa de informações locais.
- Investigação do quadro elétrico; diário separando observações de hipóteses.
- Ajuda opcional à moradora e kit de atadura.
- Um inimigo simples, empurrão, fôlego, dano, tratamento e retomada do registro salvo.
- Encerramento do trecho quando as três pistas são obtidas e Caio chega à passagem leste.
- Histórico de conversas, salvamento local, pausa, texto maior e redução de efeitos.

Este beta contém uma área de teste curta. Não é a campanha de 12 capítulos. Os textos criados para ele são uma proposta de adaptação do universo, não uma alteração do PDF original.

## Como jogar

**Celular:** arraste o controle à esquerda ou toque no chão para caminhar. Aproxime-se de um objeto ou pessoa e use o botão contextual à direita. Empurrar abre espaço. Percepção destaca pistas e consome fôlego. Toque na atadura no topo para recuperar saúde.

**Teclado:** WASD ou setas; E interage; Espaço empurra; Q alterna Percepção; J abre o diário; Esc pausa. Enter avança uma fala.

Rota sugerida: Helena → TV → quadro elétrico → passagem leste. A moradora e o kit são opcionais. Não é necessário derrotar o inimigo para terminar. Os painéis pausam o perigo durante a leitura.

## Arte integrada e próximos sprites

Integrei Caio (42 quadros de caminhada), Helena, Teresa e três retratos do seu pacote. Os originais foram preservados. A direção E da caminhada usa W espelhada temporariamente. Veja [Guia de sprites](docs/SPRITES.md) e [registro dos arquivos copiados](docs/ASSETS_INTEGRADOS.json). Cenário, props e inimigo ainda usam arte provisória autoral, reproduzível por `tools/generate_placeholders.py`. Nenhuma imagem, áudio, texto ou código foi extraído dos jogos de referência para entrar neste projeto.

## Organização

- `lib/models/campaign.dart`: estado serializado, diário e contratos de fala.
- `lib/game/world_model.dart`: movimento, colisão, caminho e encontro.
- `lib/game/game_session.dart`: regras de fluxo e interação.
- `lib/game/silencio_game.dart`: renderização, câmera e efeitos.
- `lib/ui/game_shell.dart`: menus, controle virtual, notícias e conversas.
- `lib/services/save_repository.dart`: persistência local e cópia anterior.
- `assets/data/chapter_01.json`: conteúdo narrativo do beta.
- `assets/images/`: sprites provisórios e manifesto.
- `test/`: verificações de regras, persistência e movimento.

## Verificações e compilação

O APK foi instalado e aberto no Samsung conectado. [Registro de verificação e limites](docs/VERIFICACAO_BETA.md).

```powershell
flutter analyze
flutter test
flutter build apk --debug
```

O APK de teste fica em `build/app/outputs/flutter-apk/app-debug.apk`. É uma compilação local de desenvolvimento, sem assinatura de distribuição da loja.

## Limites atuais

Arte provisória; sem áudio; apenas uma região externa; IA simples; sem combate letal; sem navegação de interiores; sem simulação de cidade, crafting ou multiplayer. A Percepção é uma primeira visualização, sem todos os puzzles do roteiro. O checkpoint local é uma base de beta, não um sistema de migração entre campanhas publicadas.

O desempenho precisa ser medido em mais aparelhos antes de aumentar cenário e elenco. A preferência por Flutter + Flame serve ao escopo 2D atual; a decisão deve ser revista se o projeto passar a exigir mundo 3D ou simulação extensa.

## Fontes técnicas

- [Flutter para jogos](https://flutter.dev/games)
- [Flame: GameWidget e ciclo de jogo](https://docs.flame-engine.org/latest/)
- [Flame: câmera e mundo](https://docs.flame-engine.org/latest/flame/camera.html)

Plano: [6 etapas de produção](docs/ETAPAS.md).
