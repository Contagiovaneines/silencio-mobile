import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:silencio/game/game_session.dart';
import 'package:silencio/models/campaign.dart';
import 'package:silencio/services/save_repository.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  late GameSession session;
  late SaveRepository repository;
  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    repository = SaveRepository(await SharedPreferences.getInstance());
    session = await GameSession.load(repository);
  });
  tearDown(() => session.dispose());

  test(
    'mandatory clues unlock ending and modal reading pauses danger',
    () async {
      session.startNew();
      session.campaign
        ..x = 28
        ..y = 14.8;
      session.interact();
      expect(session.phase, PlayPhase.playing);
      session.campaign.inspectedPanel = true;
      session.world.enemyX = 28.2;
      session.world.enemyY = 14.8;
      session.journal();
      for (var i = 0; i < 120; i++) {
        session.tick(1 / 60);
      }
      expect(session.campaign.health, 100);
      session.closePanel();
      session.campaign
        ..metHelena = true
        ..readNews = true;
      session.interact();
      expect(session.phase, PlayPhase.complete);
      await session.save();
      expect(repository.load()?.finished, isTrue);
    },
  );

  test(
    'help is granted once and delivered dialogue survives a reload',
    () async {
      session.startNew();
      session.campaign
        ..x = 8.4
        ..y = 12.4;
      session.interact();
      expect(session.phase, PlayPhase.dialogue);
      session.nextLine();
      session.nextLine();
      expect(session.campaign.helpedNeighbor, isTrue);
      expect(session.campaign.bandages, 0);
      session.interact();
      session.nextLine();
      expect(session.campaign.bandages, 0);
      await session.save();
      final loaded = repository.load()!;
      expect(loaded.history.map((line) => line.id), contains('neighbor_help'));
      expect(
        loaded.history.where((line) => line.id == 'neighbor_help').length,
        1,
      );
    },
  );

  test('malformed progress is retained instead of silently erased', () async {
    await repository.preferences.setString(SaveRepository.key, '{broken');
    expect(repository.load(), isNull);
    expect(repository.warning, isNotNull);
    expect(repository.preferences.getString(SaveRepository.key), '{broken');
  });
}
