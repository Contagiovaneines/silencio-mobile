import 'dart:async';
import 'dart:math' as math;

import 'package:flame/game.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../game/game_session.dart';
import '../game/silencio_game.dart';
import 'phase_presentation.dart';
import '../models/campaign.dart';

const mist = Color(0xffa2cbb8);
const parchment = Color(0xffe3e4d5);
const ochre = Color(0xffdfb477);

class GameShell extends StatefulWidget {
  const GameShell({super.key, required this.session, this.enableAudio = false});
  final bool enableAudio;
  final GameSession session;
  @override
  State<GameShell> createState() => _GameShellState();
}

class _GameShellState extends State<GameShell> with WidgetsBindingObserver {
  late final SilencioGame game;
  final focus = FocusNode();
  final keys = <LogicalKeyboardKey>{};
  GameSession get s => widget.session;

  @override
  void initState() {
    super.initState();
    game = SilencioGame(s, enableAudio: widget.enableAudio);
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.inactive ||
        state == AppLifecycleState.paused) {
      keys.clear();
      s.pause();
      unawaited(s.save());
    }
  }

  void _keyboard(KeyEvent event) {
    final key = event.logicalKey;
    if (event is KeyUpEvent) {
      keys.remove(key);
    } else {
      keys.add(key);
    }
    if (event is KeyDownEvent) {
      if (key == LogicalKeyboardKey.escape) {
        if (s.phase == PlayPhase.playing) {
          s.pause();
        } else if ([
          PlayPhase.paused,
          PlayPhase.journal,
          PlayPhase.map,
        ].contains(s.phase)) {
          s.closePanel();
        }
      }
      if (s.phase == PlayPhase.playing) {
        if (key == LogicalKeyboardKey.keyE) s.interact();
        if (key == LogicalKeyboardKey.space) s.push();
        if (key == LogicalKeyboardKey.keyQ) s.togglePerception();
        if (key == LogicalKeyboardKey.keyJ) s.journal();
        if (key == LogicalKeyboardKey.keyM) s.map();
        if (key == LogicalKeyboardKey.keyP) s.phone();
        if (key == LogicalKeyboardKey.keyR) s.toggleRun();
      } else if (s.phase == PlayPhase.dialogue &&
          key == LogicalKeyboardKey.enter) {
        s.nextLine();
      }
    }
    if (s.phase != PlayPhase.playing) return;
    double axis(LogicalKeyboardKey a, LogicalKeyboardKey b) =>
        keys.contains(a) || keys.contains(b) ? 1 : 0;
    final dx =
        axis(LogicalKeyboardKey.keyD, LogicalKeyboardKey.arrowRight) -
        axis(LogicalKeyboardKey.keyA, LogicalKeyboardKey.arrowLeft);
    final dy =
        axis(LogicalKeyboardKey.keyS, LogicalKeyboardKey.arrowDown) -
        axis(LogicalKeyboardKey.keyW, LogicalKeyboardKey.arrowUp);
    s.world.setInput(dx + dy * 2, -dx + dy * 2);
  }

  void _resume() {
    s.resume();
    focus.requestFocus();
  }

  Future<void> _start() async {
    if (s.hasSave) {
      final accepted = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Começar de novo?'),
          content: const Text('O progresso atual será substituído.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Voltar'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Nova exploração'),
            ),
          ],
        ),
      );
      if (accepted != true) return;
    }
    s.startNew();
    focus.requestFocus();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: KeyboardListener(
      focusNode: focus,
      autofocus: true,
      onKeyEvent: _keyboard,
      child: AnimatedBuilder(
        animation: s,
        builder: (context, _) => Stack(
          fit: StackFit.expand,
          children: [
            GestureDetector(
              onTapDown: (d) {
                game.tapGround(d.localPosition);
                focus.requestFocus();
              },
              child: GameWidget(game: game, autofocus: false),
            ),
            if (s.phase == PlayPhase.menu) _menu(),
            if (s.phase == PlayPhase.opening) _opening(),
            if (s.phase == PlayPhase.map) _map(),
            if (s.phase == PlayPhase.pulse) _pulse(),
            if (s.phase == PlayPhase.transit) _transit(),
            if (s.phase == PlayPhase.playing) ...[_hud(), _controls()],
            if (s.phase == PlayPhase.dialogue) _dialogue(),
            if (s.phase == PlayPhase.news) _news(),
            if (s.phase == PlayPhase.journal) _journal(),
            if (s.phase == PlayPhase.paused) _pause(),
            if (s.phase == PlayPhase.complete) _complete(),
            if (s.phase == PlayPhase.defeated) _defeated(),
            if (s.notice.isNotEmpty && s.phase == PlayPhase.playing)
              Positioned(
                left: 155,
                right: 240,
                bottom: 18,
                child: IgnorePointer(
                  child: _glass(
                    Padding(
                      padding: const EdgeInsets.all(10),
                      child: Text(
                        s.notice,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: parchment,
                          fontSize: 11,
                          height: 1.4,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    ),
  );

  Widget _menu() => DecoratedBox(
    decoration: const BoxDecoration(
      gradient: LinearGradient(
        colors: [Color(0xf5102029), Color(0xc5102029), Color(0x15102029)],
        stops: [0, .42, 1],
      ),
    ),
    child: SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(36, 24, 28, 18),
        child: LayoutBuilder(
          builder: (context, bounds) => Row(
            children: [
              SizedBox(
                width: math.min(420, bounds.maxWidth * .68),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'UM JOGO SOBRE O QUE AINDA É HUMANO',
                      style: TextStyle(
                        color: mist,
                        fontSize: 9,
                        letterSpacing: 2,
                      ),
                    ),
                    const Spacer(),
                    const FittedBox(
                      fit: BoxFit.scaleDown,
                      alignment: Alignment.centerLeft,
                      child: Text(
                        'SILÊNCIO',
                        style: TextStyle(
                          fontSize: 65,
                          height: 1.1,
                          letterSpacing: 7,
                          fontWeight: FontWeight.w300,
                          color: parchment,
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    const Row(
                      children: [
                        SizedBox(width: 28, child: Divider(color: ochre)),
                        SizedBox(width: 12),
                        Text(
                          'SANTA AURORA  /  UM DIA NORMAL',
                          style: TextStyle(
                            fontSize: 9,
                            color: ochre,
                            letterSpacing: 1.5,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      '07:12. Chuva de novo.\nHoje parecia ser só mais um dia.',
                      style: TextStyle(
                        color: Color(0xffa3b4b0),
                        fontSize: 13,
                        height: 1.6,
                      ),
                    ),
                    const SizedBox(height: 20),
                    Row(
                      children: [
                        FilledButton.icon(
                          onPressed: s.hasSave ? _resume : _start,
                          icon: const Icon(
                            Icons.arrow_forward_rounded,
                            size: 18,
                          ),
                          label: Text(
                            s.hasSave ? 'Continuar' : 'Começar exploração',
                          ),
                        ),
                        if (s.hasSave) ...[
                          const SizedBox(width: 8),
                          TextButton(
                            onPressed: _start,
                            child: const Text('Nova'),
                          ),
                        ],
                      ],
                    ),
                    TextButton(
                      onPressed: s.replay,
                      style: TextButton.styleFrom(padding: EdgeInsets.zero),
                      child: const Text(
                        'Reassistir à abertura  ↗',
                        style: TextStyle(
                          fontSize: 11,
                          color: Color(0xff98aaa6),
                        ),
                      ),
                    ),
                    const Spacer(),
                    const Text(
                      'FASE 01   ·   VERSÃO DE DESENVOLVIMENTO',
                      style: TextStyle(
                        color: Color(0xff718d88),
                        fontSize: 9,
                        letterSpacing: 1.2,
                      ),
                    ),
                  ],
                ),
              ),
              const Spacer(),
              const Align(
                alignment: Alignment.bottomRight,
                child: Text(
                  '07:12\nUM DIA NORMAL',
                  textAlign: TextAlign.right,
                  style: TextStyle(
                    color: Color(0xffb2c5b8),
                    height: 1.8,
                    fontSize: 10,
                    letterSpacing: 2,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    ),
  );

  Widget _hud() => Positioned(
    top: 12,
    left: 18,
    right: 18,
    child: SafeArea(
      bottom: false,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Align(
              alignment: Alignment.topLeft,
              child: _glass(
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 10,
                  ),
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 390),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            const Icon(
                              Icons.radio_button_checked,
                              size: 10,
                              color: ochre,
                            ),
                            const SizedBox(width: 7),
                            Text(
                              '${s.campaign.has('pulse') ? '18:42' : '07:12'}  ·  ${s.campaign.location}',
                              style: const TextStyle(
                                color: mist,
                                fontSize: 9,
                                letterSpacing: 1.5,
                              ),
                            ),
                            const Spacer(),
                            Text(
                              '${s.campaign.evidenceCount}/5 MARCOS',
                              style: const TextStyle(color: ochre, fontSize: 9),
                            ),
                          ],
                        ),
                        const SizedBox(height: 7),
                        Text(
                          s.campaign.objective,
                          style: const TextStyle(
                            fontSize: 12,
                            color: parchment,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            _meter(
                              s.campaign.injured ? 'BRAÇO FERIDO' : 'SAÚDE',
                              s.campaign.health,
                              const Color(0xffb99c7e),
                            ),
                            const SizedBox(width: 12),
                            _meter('FÔLEGO', s.campaign.stamina, mist),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          _glass(
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  tooltip: 'Usar atadura',
                  onPressed: s.heal,
                  icon: Badge(
                    label: Text('${s.campaign.bandages}'),
                    backgroundColor: const Color(0xff526c60),
                    child: const Icon(
                      Icons.healing_rounded,
                      size: 20,
                      color: parchment,
                    ),
                  ),
                ),
                IconButton(
                  tooltip: 'Diário e conversas',
                  onPressed: s.journal,
                  icon: const Icon(
                    Icons.menu_book_rounded,
                    size: 20,
                    color: parchment,
                  ),
                ),
                IconButton(
                  tooltip: 'Celular',
                  onPressed: s.phone,
                  icon: const Icon(Icons.smartphone_rounded),
                ),
                IconButton(
                  tooltip: 'Mapa',
                  onPressed: s.map,
                  icon: const Icon(Icons.map_outlined),
                ),
                IconButton(
                  tooltip: 'Pausar',
                  onPressed: s.pause,
                  icon: const Icon(
                    Icons.pause_rounded,
                    size: 22,
                    color: parchment,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    ),
  );

  Widget _meter(String label, double value, Color color) => Expanded(
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(
              label,
              style: const TextStyle(
                fontSize: 8,
                color: Color(0xff90a8a0),
                letterSpacing: 1,
              ),
            ),
            const Spacer(),
            Text(
              '${value.round()}',
              style: TextStyle(fontSize: 9, color: color),
            ),
          ],
        ),
        const SizedBox(height: 4),
        ClipRRect(
          borderRadius: BorderRadius.circular(2),
          child: LinearProgressIndicator(
            value: value / 100,
            color: color,
            backgroundColor: const Color(0xff32494a),
            minHeight: 3,
          ),
        ),
      ],
    ),
  );

  Widget _controls() {
    final place = s.world.nearby;
    return Positioned.fill(
      child: SafeArea(
        top: false,
        child: Stack(
          children: [
            Positioned(
              left: 24,
              bottom: 138,
              child: OutlinedButton.icon(
                onPressed: s.toggleRun,
                icon: Icon(
                  s.world.running
                      ? Icons.directions_run
                      : Icons.directions_walk,
                ),
                label: Text(s.world.running ? 'Correndo' : 'Caminhando'),
              ),
            ),
            Positioned(
              left: 24,
              bottom: 20,
              child: VirtualStick(
                onChanged: (o) =>
                    s.world.setInput(o.dx + o.dy * 2, -o.dx + o.dy * 2),
              ),
            ),
            Positioned(
              right: 22,
              bottom: 20,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  _action(
                    Icons.blur_on_rounded,
                    'Percepção',
                    s.togglePerception,
                    selected: s.world.perception,
                    small: true,
                  ),
                  const SizedBox(width: 10),
                  _action(
                    Icons.back_hand_outlined,
                    'Empurrar',
                    s.push,
                    small: true,
                  ),
                  const SizedBox(width: 12),
                  _action(
                    place == null
                        ? Icons.touch_app_outlined
                        : Icons.pan_tool_alt_outlined,
                    place?.action ?? 'Interagir',
                    s.interact,
                    selected: place != null,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _action(
    IconData icon,
    String label,
    VoidCallback action, {
    bool selected = false,
    bool small = false,
  }) => Column(
    mainAxisSize: MainAxisSize.min,
    children: [
      Semantics(
        button: true,
        label: label,
        child: Material(
          color: selected ? const Color(0xe0587a6f) : const Color(0xdb172b33),
          shape: CircleBorder(
            side: BorderSide(
              color: selected ? mist : const Color(0xff506c69),
              width: 1.2,
            ),
          ),
          child: InkWell(
            customBorder: const CircleBorder(),
            onTap: action,
            child: SizedBox(
              width: small ? 52 : 70,
              height: small ? 52 : 70,
              child: Icon(
                icon,
                color: selected ? parchment : const Color(0xffa5beb1),
                size: small ? 22 : 28,
              ),
            ),
          ),
        ),
      ),
      const SizedBox(height: 7),
      Text(
        label,
        style: TextStyle(fontSize: small ? 9 : 10, color: parchment),
      ),
    ],
  );

  Widget _dialogue() {
    final line = s.currentLine;
    final portrait = const {
      'CAIO': 'caio',
      'HELENA': 'helena',
      'INÊS': 'ines',
      'ORLANDO': 'orlando',
      'NESTOR': 'nestor',
      'MARINA': 'marina',
    }[line?.speaker];
    return _scrim(
      Align(
        alignment: Alignment.bottomCenter,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(36, 18, 36, 24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 800, maxHeight: 280),
            child: _glass(
              SingleChildScrollView(
                padding: const EdgeInsets.all(20),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        if (portrait != null) ...[
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: Image.asset(
                              'assets/images/portrait_$portrait.png',
                              width: 48,
                              height: 48,
                              fit: BoxFit.cover,
                            ),
                          ),
                          const SizedBox(width: 12),
                        ],
                        Icon(
                          line?.speaker == 'CAIO'
                              ? Icons.smartphone_rounded
                              : Icons.chat_bubble_outline,
                          size: 17,
                          color: ochre,
                        ),
                        const SizedBox(width: 10),
                        _eyebrow(
                          '${line?.speaker ?? ''}  ·  ${line?.mode.toUpperCase() ?? ''}',
                        ),
                        const Spacer(),
                        Text(
                          '${s.dialogueIndex + 1}/${s.activeLines.length}',
                          style: const TextStyle(
                            color: Color(0xff819c93),
                            fontSize: 10,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 15),
                    Text(
                      line?.text ?? '',
                      style: TextStyle(
                        fontSize: s.largerText ? 20 : 17,
                        height: 1.5,
                        color: parchment,
                      ),
                    ),
                    const SizedBox(height: 15),
                    Align(
                      alignment: Alignment.centerRight,
                      child: FilledButton.icon(
                        onPressed: s.nextLine,
                        icon: const Icon(Icons.arrow_forward_rounded, size: 17),
                        label: const Text('Continuar'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
      opacity: .2,
    );
  }

  Widget _news() {
    final pages = (s.news['pages'] as List).cast<String>();
    final ticker = (s.news['ticker'] as List).cast<String>();
    return _panel(
      maxWidth: 760,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.fiber_manual_record, color: ochre, size: 9),
              const SizedBox(width: 8),
              _eyebrow(s.news['source'] as String),
              const Spacer(),
              const Text(
                'TRANSMISSÃO LOCAL',
                style: TextStyle(
                  color: Color(0xff8eaaa1),
                  fontSize: 9,
                  letterSpacing: 1.2,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 100,
                height: 126,
                decoration: BoxDecoration(
                  color: const Color(0xff294b4c),
                  border: Border.all(color: const Color(0xff58756d)),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: const Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.cell_tower_rounded, color: mist, size: 43),
                    SizedBox(height: 10),
                    Text(
                      'SANTA\nAURORA',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 11,
                        color: parchment,
                        letterSpacing: 2,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 22),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      s.news['title'] as String,
                      style: const TextStyle(
                        color: parchment,
                        fontSize: 25,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      pages[s.newsPage],
                      style: TextStyle(
                        fontSize: s.largerText ? 18 : 15,
                        color: const Color(0xffc3d0c5),
                        height: 1.6,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          const Divider(color: Color(0xff3a5555)),
          Text(
            ticker[s.newsPage % ticker.length],
            style: const TextStyle(color: ochre, fontSize: 11),
          ),
          const SizedBox(height: 15),
          Row(
            children: [
              Text(
                'BOLETIM ${s.newsPage + 1} / ${pages.length}',
                style: const TextStyle(
                  color: mist,
                  fontSize: 9,
                  letterSpacing: 1.5,
                ),
              ),
              const Spacer(),
              FilledButton.icon(
                onPressed: s.advanceNews,
                icon: const Icon(Icons.arrow_forward_rounded, size: 16),
                label: Text(
                  s.newsPage < pages.length - 1
                      ? 'Próxima página'
                      : 'Registrar e voltar',
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _journal() => _panel(
    maxWidth: 800,
    child: SizedBox(
      height: math.min(MediaQuery.sizeOf(context).height - 100, 440),
      child: DefaultTabController(
        length: 2,
        child: Column(
          children: [
            Row(
              children: [
                _eyebrow('CADERNO DE CAIO'),
                const Spacer(),
                IconButton(
                  tooltip: 'Voltar ao jogo',
                  onPressed: s.closePanel,
                  icon: const Icon(Icons.close_rounded),
                ),
              ],
            ),
            const TabBar(
              tabs: [
                Tab(text: 'Pistas e hipóteses'),
                Tab(text: 'Conversas'),
              ],
            ),
            Expanded(
              child: TabBarView(
                children: [
                  ListView.separated(
                    padding: const EdgeInsets.only(top: 12),
                    itemCount: s.campaign.entries.length,
                    separatorBuilder: (_, _) =>
                        const Divider(color: Color(0xff304c4b)),
                    itemBuilder: (context, index) {
                      final e = s.campaign.entries[index];
                      return Padding(
                        padding: const EdgeInsets.symmetric(vertical: 8),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              e.kind,
                              style: TextStyle(
                                color: e.kind == 'HIPÓTESE' ? ochre : mist,
                                fontSize: 9,
                                letterSpacing: 1.4,
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              e.title,
                              style: const TextStyle(
                                color: parchment,
                                fontSize: 17,
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              e.text,
                              style: TextStyle(
                                color: const Color(0xffb0c4ba),
                                height: 1.5,
                                fontSize: s.largerText ? 17 : 14,
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                  s.campaign.history.isEmpty
                      ? const Center(
                          child: Text('As conversas aparecerão aqui.'),
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.only(top: 12),
                          itemCount: s.campaign.history.length,
                          itemBuilder: (context, index) {
                            final line = s.campaign.history[index];
                            return Padding(
                              padding: const EdgeInsets.symmetric(vertical: 10),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    '${line.speaker} · ${line.mode.toUpperCase()}',
                                    style: const TextStyle(
                                      color: mist,
                                      fontSize: 10,
                                      letterSpacing: 1.2,
                                    ),
                                  ),
                                  const SizedBox(height: 7),
                                  Text(
                                    line.text,
                                    style: TextStyle(
                                      color: parchment,
                                      height: 1.5,
                                      fontSize: s.largerText ? 17 : 14,
                                    ),
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                ],
              ),
            ),
          ],
        ),
      ),
    ),
  );

  Widget _pause() => _panel(
    maxWidth: 560,
    child: Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _eyebrow('UM INSTANTE DE SILÊNCIO'),
        const SizedBox(height: 12),
        const Text(
          'A cidade pode esperar.',
          style: TextStyle(
            color: parchment,
            fontSize: 27,
            fontWeight: FontWeight.w300,
          ),
        ),
        SwitchListTile.adaptive(
          contentPadding: EdgeInsets.zero,
          title: const Text('Sons e ambiente'),
          value: s.soundEnabled,
          onChanged: (_) => s.toggleSound(),
        ),
        SwitchListTile.adaptive(
          contentPadding: EdgeInsets.zero,
          title: const Text(
            'Reduzir chuva e pulsos',
            style: TextStyle(fontSize: 14),
          ),
          value: s.reducedEffects,
          onChanged: (_) => s.toggleEffects(),
        ),
        SwitchListTile.adaptive(
          contentPadding: EdgeInsets.zero,
          title: const Text('Texto maior', style: TextStyle(fontSize: 14)),
          value: s.largerText,
          onChanged: (_) => s.toggleText(),
        ),
        const Text(
          'WASD/setas: mover · E: interagir · Espaço: empurrar · R: correr · Q: Percepção · M: mapa · P: celular · J: diário · Esc: voltar.',
          style: TextStyle(color: Color(0xff91aca2), fontSize: 11, height: 1.5),
        ),
        const SizedBox(height: 18),
        Wrap(
          spacing: 12,
          runSpacing: 8,
          children: [
            FilledButton(
              onPressed: s.closePanel,
              child: const Text('Continuar'),
            ),
            OutlinedButton(
              onPressed: () => unawaited(s.toMenu()),
              child: const Text('Salvar e voltar ao menu'),
            ),
          ],
        ),
      ],
    ),
  );

  Widget _complete() => _panel(
    maxWidth: 620,
    child: Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _eyebrow('FASE 01 CONCLUÍDA'),
        const SizedBox(height: 15),
        const Text(
          'Um Dia Normal.',
          style: TextStyle(
            color: parchment,
            fontSize: 34,
            fontWeight: FontWeight.w300,
          ),
        ),
        const SizedBox(height: 14),
        const Text(
          'De volta ao apartamento. O pulso passou, mas o aviso de Helena ficou.\nHoje, às duas. O próximo capítulo começa nesse horário.',
          style: TextStyle(color: Color(0xffb6c9bd), fontSize: 15, height: 1.7),
        ),
        const SizedBox(height: 16),
        Text(
          s.campaign.has('help_ines')
              ? 'Dona Inês se lembra da sua ajuda no hall.'
              : 'O encontro terminou sem matar Davi.',
          style: const TextStyle(color: ochre, fontSize: 12, height: 1.5),
        ),
        const SizedBox(height: 20),
        Row(
          children: [
            const Text(
              'PROGRESSO SALVO · 02:00 DESBLOQUEADO',
              style: TextStyle(color: mist, fontSize: 10, letterSpacing: 1.5),
            ),
            const Spacer(),
            FilledButton(
              onPressed: () => unawaited(s.toMenu()),
              child: const Text('Voltar ao menu'),
            ),
          ],
        ),
      ],
    ),
  );

  Widget _defeated() => _panel(
    maxWidth: 500,
    child: Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _eyebrow('VOCÊ PRECISA DE OUTRA SAÍDA'),
        const SizedBox(height: 16),
        const Text(
          'Ainda não acabou.',
          style: TextStyle(
            fontSize: 30,
            color: parchment,
            fontWeight: FontWeight.w300,
          ),
        ),
        const SizedBox(height: 14),
        const Text(
          'Recuar e empurrar criam espaço. A passagem não exige derrotar o morador.',
          style: TextStyle(color: Color(0xffb4c6ba), height: 1.6),
        ),
        const SizedBox(height: 20),
        FilledButton(
          onPressed: () => unawaited(s.retry()),
          child: const Text('Retomar o último registro'),
        ),
      ],
    ),
  );

  Widget _opening() => ColoredBox(
    color: const Color(0xff07151c),
    child: Stack(
      children: [
        Positioned.fill(
          child: CustomPaint(
            painter: OpeningArt(
              s.sceneTime + s.openingPage * 13,
              s.openingPage,
            ),
          ),
        ),
        Positioned(
          left: 36,
          right: 36,
          bottom: 24,
          child: _glass(
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _eyebrow(GameSession.opening[s.openingPage].$1),
                  const SizedBox(height: 12),
                  Text(
                    GameSession.opening[s.openingPage].$2,
                    style: const TextStyle(
                      color: parchment,
                      fontSize: 17,
                      height: 1.5,
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      TextButton(
                        onPressed: s.finishOpening,
                        child: const Text('Pular abertura'),
                      ),
                      const SizedBox(width: 16),
                      FilledButton(
                        onPressed: s.nextOpening,
                        child: const Text('Avançar'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
        Positioned(
          top: 20,
          right: 30,
          child: Text(
            '${s.openingPage + 1} / 5',
            style: const TextStyle(color: mist),
          ),
        ),
      ],
    ),
  );
  Widget _map() => _panel(
    maxWidth: 960,
    child: Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(child: _eyebrow('SANTA AURORA · FASE 01')),
            IconButton(onPressed: s.closePanel, icon: const Icon(Icons.close)),
          ],
        ),
        Text(
          s.campaign.objective,
          style: const TextStyle(color: parchment, fontSize: 14),
        ),
        const SizedBox(height: 10),
        SizedBox(
          height: math.min(360, MediaQuery.sizeOf(context).height * .48),
          width: 850,
          child: CustomPaint(painter: ChapterMap(s.campaign, s.world)),
        ),
        const Text(
          'Ponto claro: você · Dourado: interação · Blocos: edifícios e veículos.',
          style: TextStyle(color: mist, fontSize: 11),
        ),
      ],
    ),
  );
  Widget _pulse() => IgnorePointer(
    child: ColoredBox(
      color: Color.fromRGBO(
        177,
        204,
        183,
        s.reducedEffects ? .12 : .16 + math.sin(s.sceneTime * math.pi) * .15,
      ),
      child: Center(
        child: _glass(
          const Padding(
            padding: EdgeInsets.all(22),
            child: Text(
              'A cidade parou. Você continua consciente.',
              style: TextStyle(color: parchment, fontSize: 20),
            ),
          ),
        ),
      ),
    ),
  );
  Widget _transit() => Align(
    alignment: Alignment.bottomCenter,
    child: Padding(
      padding: const EdgeInsets.all(24),
      child: _glass(
        const Padding(
          padding: EdgeInsets.all(18),
          child: Text(
            'No ônibus de Nestor · próxima esquina',
            style: TextStyle(color: parchment, fontSize: 17),
          ),
        ),
      ),
    ),
  );

  Widget _panel({required Widget child, double maxWidth = 700}) => _scrim(
    Center(
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: BoxConstraints(
              maxWidth: maxWidth,
              maxHeight: MediaQuery.sizeOf(context).height - 48,
            ),
            child: _glass(
              SingleChildScrollView(
                padding: const EdgeInsets.all(24),
                child: child,
              ),
            ),
          ),
        ),
      ),
    ),
  );
  Widget _scrim(Widget child, {double opacity = .65}) => ColoredBox(
    color: const Color(0xff08171e).withValues(alpha: opacity),
    child: child,
  );
  Widget _glass(Widget child) => Material(
    color: const Color(0xf5182a32),
    elevation: 8,
    shadowColor: const Color(0x40101d23),
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(10),
      side: const BorderSide(color: Color(0xff415c57)),
    ),
    clipBehavior: Clip.antiAlias,
    child: child,
  );
  Widget _eyebrow(String text) => Text(
    text,
    style: const TextStyle(
      color: mist,
      fontSize: 10,
      letterSpacing: 1.5,
      fontWeight: FontWeight.w600,
    ),
  );
  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    focus.dispose();
    super.dispose();
  }
}

class VirtualStick extends StatefulWidget {
  const VirtualStick({super.key, required this.onChanged});
  final ValueChanged<Offset> onChanged;
  @override
  State<VirtualStick> createState() => _VirtualStickState();
}

class _VirtualStickState extends State<VirtualStick> {
  Offset offset = Offset.zero;
  void _move(Offset position) {
    var next = position - const Offset(53, 53);
    if (next.distance > 37) next = next / next.distance * 37;
    setState(() => offset = next);
    widget.onChanged(next / 37);
  }

  void _release() {
    setState(() => offset = Offset.zero);
    widget.onChanged(Offset.zero);
  }

  @override
  Widget build(BuildContext context) => Semantics(
    label: 'Controle de movimento',
    child: GestureDetector(
      behavior: HitTestBehavior.opaque,
      onPanStart: (d) => _move(d.localPosition),
      onPanUpdate: (d) => _move(d.localPosition),
      onPanEnd: (_) => _release(),
      onPanCancel: _release,
      child: Container(
        width: 106,
        height: 106,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: const Color(0x9a192f35),
          border: Border.all(color: const Color(0xff536f68)),
        ),
        child: Stack(
          children: [
            const Center(
              child: Icon(Icons.add, color: Color(0x506f9586), size: 42),
            ),
            Positioned(
              left: 34 + offset.dx,
              top: 34 + offset.dy,
              child: Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: const Color(0xc1799b89),
                  border: Border.all(color: mist.withValues(alpha: .75)),
                  boxShadow: const [
                    BoxShadow(color: Color(0x400e2227), blurRadius: 8),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    ),
  );
}
