import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:silencio/game/game_session.dart';
import 'package:silencio/services/save_repository.dart';
import 'package:silencio/ui/game_shell.dart';

void main() {
  testWidgets('small landscape phone can start, read dialogue and pause', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(832, 384);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    SharedPreferences.setMockInitialValues({});
    final session = await GameSession.load(
      SaveRepository(await SharedPreferences.getInstance()),
    );
    await tester.pumpWidget(MaterialApp(home: GameShell(session: session)));
    await tester.pump(const Duration(milliseconds: 100));
    expect(tester.takeException(), isNull);
    await tester.tap(find.text('Começar exploração'));
    await tester.pump();
    session.campaign
      ..x = 15.5
      ..y = 14;
    session.interact();
    await tester.pump();
    expect(find.textContaining('A torre não devia'), findsOneWidget);
    expect(tester.takeException(), isNull);
    await tester.pumpWidget(const SizedBox());
    session.dispose();
  });
}
