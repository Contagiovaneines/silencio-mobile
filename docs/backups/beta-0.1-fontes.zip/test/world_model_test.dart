import 'dart:math' as math;

import 'package:flutter_test/flutter_test.dart';
import 'package:silencio/game/world_model.dart';
import 'package:silencio/models/campaign.dart';

void main() {
  test('diagonal movement has the same speed and respects building walls', () {
    final a = WorldModel(
      Campaign()
        ..x = 10
        ..y = 17,
    );
    final b = WorldModel(
      Campaign()
        ..x = 10
        ..y = 17,
    );
    a.setInput(1, 0);
    b.setInput(1, 1);
    for (var i = 0; i < 60; i++) {
      a.update(1 / 60);
      b.update(1 / 60);
    }
    double moved(WorldModel world) => math.sqrt(
      math.pow(world.campaign.x - 10, 2) + math.pow(world.campaign.y - 17, 2),
    );
    expect(moved(a), closeTo(moved(b), .001));
    final wall = WorldModel(
      Campaign()
        ..x = 13.8
        ..y = 10.6,
    )..setInput(-1, 0);
    for (var i = 0; i < 120; i++) {
      wall.update(1 / 60);
    }
    expect(wall.campaign.x, greaterThanOrEqualTo(13.23));
    expect(wall.isOpen(wall.campaign.x, wall.campaign.y), isTrue);
  });

  test('tap path routes around obstacles and reaches the television', () {
    final world = WorldModel(Campaign());
    world.moveTo(19, 12.2);
    expect(world.path, isNotEmpty);
    for (var i = 0; i < 900; i++) {
      world.update(1 / 60);
      expect(world.isOpen(world.campaign.x, world.campaign.y), isTrue);
    }
    expect(world.distance(19.5, 12.5), lessThan(.2));
    expect(world.nearby?.kind, PointKind.television);
  });

  test('push consumes effort once, creates space and has a cooldown', () {
    final world = WorldModel(Campaign()..inspectedPanel = true);
    world.enemyX = world.campaign.x + 1;
    world.enemyY = world.campaign.y;
    expect(world.push(), isTrue);
    final effort = world.campaign.stamina;
    expect(world.push(), isFalse);
    expect(world.campaign.stamina, effort);
    final distance = world.distance(world.enemyX, world.enemyY);
    for (var i = 0; i < 30; i++) {
      world.update(1 / 60);
    }
    expect(world.distance(world.enemyX, world.enemyY), greaterThan(distance));
    expect(world.enemyStun, greaterThan(0));
  });
}
