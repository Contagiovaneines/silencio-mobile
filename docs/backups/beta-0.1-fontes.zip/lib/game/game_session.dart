import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

import '../models/campaign.dart';
import '../services/save_repository.dart';
import 'world_model.dart';

class GameSession extends ChangeNotifier {
  GameSession(this.repository, this.lines, this.news)
    : world = WorldModel(Campaign()) {
    final saved = repository.load();
    if (saved != null) {
      world.restore(saved);
      hasSave = true;
    }
    notice = repository.warning ?? '';
  }
  final SaveRepository repository;
  final List<DialogueLine> lines;
  final Map<String, dynamic> news;
  final WorldModel world;
  Campaign get campaign => world.campaign;
  PlayPhase phase = PlayPhase.menu;
  bool hasSave = false;
  bool reducedEffects = false;
  bool largerText = false;
  String notice = '';
  double noticeTime = 0;
  double elapsed = 0, _uiElapsed = 0;
  int newsPage = 0, dialogueIndex = 0;
  List<DialogueLine> activeLines = [];
  VoidCallback? _afterDialogue;
  bool _choicePending = false;
  bool get showChoice => _choicePending && dialogueIndex >= activeLines.length;
  DialogueLine? get currentLine =>
      dialogueIndex < activeLines.length ? activeLines[dialogueIndex] : null;

  static Future<GameSession> load(SaveRepository repository) async {
    final raw = await rootBundle.loadString('assets/data/chapter_01.json');
    final data = jsonDecode(raw) as Map<String, dynamic>;
    final lines = (data['dialogue'] as List)
        .map((v) => DialogueLine.fromJson(v as Map<String, dynamic>))
        .toList();
    final ids = lines.map((line) => line.id).toSet();
    if (ids.length != lines.length) {
      throw const FormatException('Há falas com IDs repetidos.');
    }
    return GameSession(repository, lines, data['news'] as Map<String, dynamic>);
  }

  void _change(PlayPhase value) {
    phase = value;
    world.setInput(0, 0);
    world.path.clear();
    notifyListeners();
  }

  void tick(double dt) {
    elapsed += dt;
    if (noticeTime > 0) {
      noticeTime -= dt;
      if (noticeTime <= 0) notice = '';
    }
    if (phase == PlayPhase.playing) {
      world.update(dt);
      if (campaign.health <= 0) _change(PlayPhase.defeated);
    }
    _uiElapsed += dt;
    if (_uiElapsed >= .1) {
      _uiElapsed = 0;
      notifyListeners();
    }
  }

  void tell(String text) {
    notice = text;
    noticeTime = 4.5;
    notifyListeners();
  }

  void startNew() {
    world.restore(Campaign());
    elapsed = 0;
    _change(PlayPhase.playing);
    tell('Helena está perto da mercearia. Toque no chão ou use o controle.');
    unawaited(save());
  }

  void resume() {
    final saved = repository.load();
    if (saved != null) {
      world.restore(saved);
      _change(saved.finished ? PlayPhase.complete : PlayPhase.playing);
    } else {
      tell(repository.warning ?? 'Ainda não existe um progresso salvo.');
    }
  }

  Future<void> save() async {
    try {
      await repository.save(campaign);
      hasSave = true;
    } catch (_) {
      tell('Não foi possível salvar agora. Sua partida continua aberta.');
    }
  }

  Future<void> toMenu() async {
    _change(PlayPhase.paused);
    await save();
    _change(PlayPhase.menu);
  }

  void pause() {
    if (phase == PlayPhase.playing) _change(PlayPhase.paused);
  }

  void closePanel() => _change(PlayPhase.playing);
  void journal() => _change(PlayPhase.journal);
  void toggleEffects() {
    reducedEffects = !reducedEffects;
    notifyListeners();
  }

  void toggleText() {
    largerText = !largerText;
    notifyListeners();
  }

  void togglePerception() {
    if (phase != PlayPhase.playing) return;
    if (!world.perception && campaign.stamina < 15) {
      tell('Recupere o fôlego antes de observar o sinal.');
      return;
    }
    world.perception = !world.perception;
    notifyListeners();
  }

  void push() {
    if (phase != PlayPhase.playing) return;
    if (!world.push()) tell('Um instante para recuperar o fôlego.');
    notifyListeners();
  }

  void heal() {
    if (phase != PlayPhase.playing) return;
    if (campaign.bandages <= 0) {
      tell('Você está sem ataduras.');
      return;
    }
    if (campaign.health >= 100) {
      tell('Você não precisa de uma atadura agora.');
      return;
    }
    campaign.bandages--;
    campaign.health = (campaign.health + 35).clamp(0, 100);
    tell('Ferimento tratado.');
    unawaited(save());
  }

  void interact() {
    if (phase != PlayPhase.playing) return;
    final place = world.nearby;
    if (place == null) {
      tell('Chegue mais perto de uma pessoa ou de uma pista.');
      return;
    }
    switch (place.kind) {
      case PointKind.helena:
        if (campaign.metHelena) {
          _openDialogue([
            const DialogueLine(
              'helena_repeat',
              'HELENA',
              'fala',
              'A passagem fica a leste. Compare a TV e o quadro antes de ir. Eu acompanho quem precisar.',
            ),
          ]);
        } else {
          _openDialogue(
            lines,
            choices: true,
            after: () {
              campaign.metHelena = true;
              unawaited(save());
            },
          );
        }
      case PointKind.television:
        newsPage = 0;
        _change(PlayPhase.news);
      case PointKind.panel:
        _openDialogue(
          [
            const DialogueLine(
              'panel_read',
              'CAIO',
              'escrita',
              '01:58. Acionamento remoto. O quadro ligou a rede dois minutos antes do aviso.',
            ),
            const DialogueLine(
              'panel_hypothesis',
              'CAIO',
              'celular',
              'Helena, o horário foi alterado aqui também. Ainda não sei quem enviou a ordem.',
            ),
          ],
          after: () {
            final first = !campaign.inspectedPanel;
            campaign.inspectedPanel = true;
            if (first) {
              tell(
                'Passos na rua. O empurrão cria espaço; você pode passar sem lutar.',
              );
            }
            unawaited(save());
          },
        );
      case PointKind.neighbor:
        if (campaign.helpedNeighbor) {
          _openDialogue([
            const DialogueLine(
              'neighbor_safe',
              'MORADORA',
              'fala',
              'Helena disse que vai comigo. Obrigada por voltar.',
            ),
          ]);
        } else if (campaign.bandages > 0) {
          _openDialogue(
            [
              const DialogueLine(
                'neighbor_ask',
                'MORADORA',
                'fala',
                'Cortei a mão quando a luz caiu. Você tem alguma coisa para cobrir?',
              ),
              const DialogueLine(
                'neighbor_help',
                'CAIO',
                'celular',
                'Tenho uma atadura. Fique perto da porta. Vou pedir que Helena venha.',
              ),
            ],
            after: () {
              if (!campaign.helpedNeighbor) {
                campaign.bandages--;
                campaign.helpedNeighbor = true;
                unawaited(save());
              }
            },
          );
        } else {
          tell(
            'Há um kit ao sul da rua. A saída principal continua disponível.',
          );
        }
      case PointKind.bandage:
        campaign.pickedBandage = true;
        campaign.bandages = (campaign.bandages + 1).clamp(0, 10);
        tell('Uma atadura recolhida.');
        unawaited(save());
      case PointKind.exit:
        if (campaign.canLeave) {
          campaign.finished = true;
          _change(PlayPhase.complete);
          unawaited(save());
        } else {
          tell('Antes de atravessar: ${campaign.objective}');
        }
    }
  }

  void _openDialogue(
    List<DialogueLine> value, {
    bool choices = false,
    VoidCallback? after,
  }) {
    activeLines = value;
    dialogueIndex = 0;
    _choicePending = choices;
    _afterDialogue = after;
    _change(PlayPhase.dialogue);
    _rememberLine();
  }

  void _rememberLine() {
    final line = currentLine;
    if (line != null && !campaign.history.any((seen) => seen.id == line.id)) {
      campaign.history.add(line);
    }
  }

  void nextLine() {
    if (phase != PlayPhase.dialogue) return;
    dialogueIndex++;
    if (dialogueIndex >= activeLines.length && !_choicePending) {
      _finishDialogue();
    } else {
      _rememberLine();
      notifyListeners();
    }
  }

  void choose(String value) {
    if (!showChoice) return;
    campaign.choice = value;
    _choicePending = false;
    _finishDialogue();
  }

  void _finishDialogue() {
    final callback = _afterDialogue;
    _afterDialogue = null;
    _change(PlayPhase.playing);
    callback?.call();
    unawaited(save());
  }

  void advanceNews() {
    if (phase != PlayPhase.news) return;
    final pages = news['pages'] as List;
    if (newsPage < pages.length - 1) {
      newsPage++;
      notifyListeners();
    } else {
      campaign.readNews = true;
      _change(PlayPhase.playing);
      tell('Boletim registrado no diário.');
      unawaited(save());
    }
  }
}
