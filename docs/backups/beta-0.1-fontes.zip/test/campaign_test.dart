import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:silencio/models/campaign.dart';

void main() {
  test(
    'save preserves decisions, resources and the actual delivered dialogue',
    () {
      final state = Campaign()
        ..metHelena = true
        ..readNews = true
        ..inspectedPanel = true
        ..helpedNeighbor = true
        ..choice = 'ajudar'
        ..bandages = 0
        ..x = 19.5
        ..y = 12.5;
      state.history.add(
        const DialogueLine('custom_01', 'CAIO', 'escrita', 'O horário mudou.'),
      );
      final restored = Campaign.decode(state.encode());
      expect(restored.toJson(), state.toJson());
      expect(restored.history.single.mode, 'escrita');
      expect(restored.canLeave, isTrue);
    },
  );

  test('invalid save versions and impossible chapter endings are rejected', () {
    final data = Campaign().toJson();
    data['schema_version'] = 99;
    expect(() => Campaign.decode(jsonEncode(data)), throwsFormatException);
    data['schema_version'] = 1;
    data['finished'] = true;
    expect(() => Campaign.decode(jsonEncode(data)), throwsFormatException);
    data['finished'] = false;
    data['health'] = -4;
    expect(() => Campaign.decode(jsonEncode(data)), throwsFormatException);
  });

  test('Caio cannot receive a vocal dialogue by content mistake', () {
    expect(
      () => DialogueLine.fromJson({
        'id': 'bad',
        'speaker': 'CAIO',
        'mode': 'fala',
        'text': 'Oi',
      }),
      throwsFormatException,
    );
  });
}
