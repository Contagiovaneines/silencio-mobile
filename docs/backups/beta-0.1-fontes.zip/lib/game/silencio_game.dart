import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flame/game.dart';
import 'package:flutter/painting.dart';

import '../models/campaign.dart';
import 'game_session.dart';
import 'world_model.dart';

class SilencioGame extends FlameGame {
  SilencioGame(this.session);
  final GameSession session;
  final Map<String, ui.Image> _sprites = {};
  final Map<String, TextPainter> _labels = {};
  ui.Picture? _ground;
  bool _ready = false;
  double _cameraX = 0, _cameraY = 0;
  double get zoom => (size.y / 560).clamp(.78, 1.35);
  static const ink = Color(0xff102029);
  static const teal = Color(0xff91beb1);
  static const amber = Color(0xffdfb477);

  Offset iso(double x, double y) => Offset((x - y) * 32, (x + y) * 16);

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    for (final name in ['caio', 'helena', 'neighbor', 'dominated']) {
      _sprites[name] = await images.load('${name}_sheet.png');
    }
    _sprites['props'] = await images.load('props.png');
    for (final direction in ['N', 'NE', 'SE', 'S', 'SW', 'W', 'NW']) {
      for (var frame = 0; frame < 6; frame++) {
        final key = 'user_caio_${direction}_$frame';
        _sprites[key] = await images.load('$key.png');
      }
    }
    for (final name in ['helena', 'neighbor', 'caio_idle']) {
      _sprites['user_$name'] = await images.load('user_$name.png');
    }
    final recorder = ui.PictureRecorder();
    _drawGround(Canvas(recorder));
    _ground = recorder.endRecording();
    final p = iso(session.campaign.x, session.campaign.y);
    _cameraX = p.dx;
    _cameraY = p.dy;
    _ready = true;
  }

  @override
  void update(double dt) {
    super.update(dt);
    session.tick(dt);
    final p = iso(session.campaign.x, session.campaign.y);
    final blend = 1 - math.exp(-dt * 7);
    _cameraX += (p.dx - _cameraX) * blend;
    _cameraY += (p.dy - _cameraY) * blend;
  }

  void tapGround(Offset screen) {
    if (session.phase != PlayPhase.playing) return;
    final local =
        (screen - Offset(size.x * .5, size.y * .53)) / zoom +
        Offset(_cameraX, _cameraY);
    final x = (local.dx / 32 + local.dy / 16) / 2;
    final y = (local.dy / 16 - local.dx / 32) / 2;
    session.world.moveTo(x, y);
  }

  Paint _paint(Color color) => Paint()..color = color;
  Path _poly(List<Offset> points) => Path()..addPolygon(points, true);

  void _drawGround(Canvas c) {
    for (var y = 0; y < WorldModel.height; y++) {
      for (var x = 0; x < WorldModel.width; x++) {
        final noise = ((x * 71 + y * 31) % 13) - 6;
        final road = (y >= 13 && y < 17) || (x >= 15 && x < 18);
        final walk = (y >= 11 && y < 19) || (x >= 13 && x < 20);
        final base = road
            ? const Color(0xff263b42)
            : walk
            ? const Color(0xff3d5051)
            : const Color(0xff263f3a);
        final color = Color.fromARGB(
          255,
          (base.r * 255 + noise).round().clamp(0, 255),
          (base.g * 255 + noise).round().clamp(0, 255),
          (base.b * 255 + noise).round().clamp(0, 255),
        );
        final points = [
          iso(x.toDouble(), y.toDouble()),
          iso(x + 1.0, y.toDouble()),
          iso(x + 1.0, y + 1.0),
          iso(x.toDouble(), y + 1.0),
        ];
        c.drawPath(_poly(points), _paint(color));
        if (!road) {
          c.drawPath(
            _poly(points),
            Paint()
              ..color = const Color(0x16203135)
              ..style = PaintingStyle.stroke
              ..strokeWidth = .65,
          );
        }
        if (road && (x + y) % 7 == 0) {
          final p = iso(x + .5, y + .5);
          c.drawOval(
            Rect.fromCenter(center: p, width: 32, height: 8),
            _paint(const Color(0x5036525b)),
          );
          c.drawLine(
            p - const Offset(8, 0),
            p + const Offset(4, 0),
            _paint(const Color(0x455d7d80))..strokeWidth = 1,
          );
        }
      }
    }
    for (var x = 1.0; x < 30; x += 2) {
      c.drawLine(
        iso(x, 15),
        iso(x + .9, 15),
        _paint(const Color(0xff8a8056))..strokeWidth = 2.2,
      );
    }
    for (var y = 2.0; y < 24; y += 2) {
      c.drawLine(
        iso(16.5, y),
        iso(16.5, y + .85),
        _paint(const Color(0xff8a8056))..strokeWidth = 2.2,
      );
    }
    // Street drainage and paving edges belong to the ground, not actor collision.
    for (final y in [11.8, 18.3]) {
      c.drawLine(
        iso(1, y),
        iso(30, y),
        _paint(const Color(0xff6c7771))..strokeWidth = 2,
      );
    }
  }

  @override
  void render(Canvas canvas) {
    super.render(canvas);
    final c = canvas;
    c.drawRect(Rect.fromLTWH(0, 0, size.x, size.y), _paint(ink));
    if (!_ready) return;
    c.save();
    c.translate(size.x * .5, size.y * .53);
    c.scale(zoom);
    c.translate(-_cameraX, -_cameraY);
    c.drawPicture(_ground!);
    _drawTower(c);
    _drawPath(c);
    final draws =
        <
          ({
            double depth,
            void Function() draw,
            Rect? footprint,
            Offset? position,
          })
        >[];
    for (final block in WorldModel.blocks) {
      draws.add((
        depth: block.bounds.right + block.bounds.bottom,
        footprint: block.bounds,
        position: null,
        draw: () => _building(c, block),
      ));
    }
    for (final p in [
      const Offset(7, 14),
      const Offset(21, 18.5),
      const Offset(26, 12),
    ]) {
      draws.add((
        depth: p.dx + p.dy,
        footprint: null,
        position: p,
        draw: () => _lamp(c, p.dx, p.dy),
      ));
    }
    for (final place in WorldModel.places) {
      if (place.kind == PointKind.bandage && session.campaign.pickedBandage) {
        continue;
      }
      draws.add((
        depth: place.x + place.y,
        footprint: null,
        position: Offset(place.x, place.y),
        draw: () => _place(c, place),
      ));
    }
    final player = session.campaign;
    draws.add((
      depth: player.x + player.y,
      footprint: null,
      position: Offset(player.x, player.y),
      draw: () => _actor(
        c,
        'caio',
        player.x,
        player.y,
        session.world.facingX,
        session.world.facingY,
        session.world.path.isNotEmpty ||
            session.world.inputX != 0 ||
            session.world.inputY != 0,
      ),
    ));
    if (player.inspectedPanel) {
      draws.add((
        depth: session.world.enemyX + session.world.enemyY,
        footprint: null,
        position: Offset(session.world.enemyX, session.world.enemyY),
        draw: () => _enemy(c),
      ));
    }
    draws.sort((a, b) => a.depth.compareTo(b.depth));
    // A building spans several tiles: its far corner alone cannot order actors.
    // Constrain only overlapping projected footprints, then draw ready nodes by depth.
    final edges = List.generate(draws.length, (_) => <int>{});
    final incoming = List.filled(draws.length, 0);
    for (var i = 0; i < draws.length; i++) {
      final bounds = draws[i].footprint;
      if (bounds == null) continue;
      for (var j = 0; j < draws.length; j++) {
        final point = draws[j].position;
        if (point == null) continue;
        final projectedX = point.dx - point.dy;
        if (projectedX < bounds.left - bounds.bottom ||
            projectedX > bounds.right - bounds.top) {
          continue;
        }
        final inFront = point.dy >= bounds.bottom || point.dx >= bounds.right;
        final from = inFront ? i : j;
        final to = inFront ? j : i;
        if (edges[from].add(to)) incoming[to]++;
      }
    }
    final remaining = List.generate(draws.length, (i) => i);
    while (remaining.isNotEmpty) {
      final index = remaining.firstWhere(
        (i) => incoming[i] == 0,
        orElse: () => remaining.first,
      );
      remaining.remove(index);
      draws[index].draw();
      for (final next in edges[index]) {
        incoming[next]--;
      }
    }
    if (session.world.perception) {
      final center = iso(player.x, player.y);
      c.drawOval(
        Rect.fromCenter(center: center, width: 290, height: 145),
        Paint()
          ..color = const Color(0x554bd1c0)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2,
      );
    }
    c.restore();
    _rain(c);
    final vignette = ui.Gradient.radial(
      Offset(size.x * .5, size.y * .5),
      size.x * .65,
      [const Color(0x00102029), const Color(0x85102029)],
      [.35, 1],
    );
    c.drawRect(Rect.fromLTWH(0, 0, size.x, size.y), Paint()..shader = vignette);
  }

  void _drawPath(Canvas c) {
    if (session.world.path.isEmpty) return;
    for (var i = 0; i < session.world.path.length; i += 2) {
      final point = session.world.path[i];
      c.drawOval(
        Rect.fromCenter(center: iso(point.dx, point.dy), width: 5, height: 3),
        _paint(const Color(0x6595c4b5)),
      );
    }
    final last = session.world.path.last;
    c.drawOval(
      Rect.fromCenter(center: iso(last.dx, last.dy), width: 23, height: 11),
      Paint()
        ..color = const Color(0xaa95c4b5)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.5,
    );
  }

  void _building(Canvas c, Block block) {
    final b = block.bounds;
    final base = [
      iso(b.left, b.top),
      iso(b.right, b.top),
      iso(b.right, b.bottom),
      iso(b.left, b.bottom),
    ];
    final roof = base.map((p) => p - Offset(0, block.height)).toList();
    final behind =
        session.campaign.y < b.top &&
        session.campaign.y > b.top - 4 &&
        session.campaign.x > b.left - 2 &&
        session.campaign.x < b.right + 2;
    final alpha = behind ? .5 : 1.0;
    Color fade(Color color) => color.withValues(alpha: alpha);
    c.drawPath(
      _poly(base.map((p) => p + const Offset(14, 10)).toList()),
      _paint(const Color(0x49202c2c)),
    );
    c.drawPath(
      _poly([base[3], base[2], roof[2], roof[3]]),
      _paint(fade(const Color(0xff23383f))),
    );
    c.drawPath(
      _poly([base[1], base[2], roof[2], roof[1]]),
      _paint(fade(const Color(0xff334b50))),
    );
    c.drawPath(
      _poly(roof),
      _paint(
        fade(
          block.style == 1 ? const Color(0xff49615d) : const Color(0xff344e51),
        ),
      ),
    );
    c.drawPath(
      _poly(roof),
      Paint()
        ..color = fade(const Color(0xff6b7a70))
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.5,
    );
    for (var floor = 0; floor < (block.height / 32).floor(); floor++) {
      final up = 18.0 + floor * 30;
      for (var j = 1; j < 6; j++) {
        final p = Offset.lerp(base[3], base[2], j / 6)! - Offset(0, up);
        c.drawPath(
          _poly([
            p,
            p + const Offset(12, 6),
            p + const Offset(12, -6),
            p + const Offset(0, -12),
          ]),
          _paint(
            fade(
              (j + floor) % 4 == 0
                  ? const Color(0xffab9266)
                  : const Color(0xff142d36),
            ),
          ),
        );
      }
    }
    for (var j = 1; j < 5; j++) {
      final p = Offset.lerp(base[1], base[2], j / 5)! - const Offset(0, 34);
      c.drawPath(
        _poly([
          p,
          p + const Offset(-13, 6),
          p + const Offset(-13, -10),
          p + const Offset(0, -16),
        ]),
        _paint(
          fade(j.isEven ? const Color(0xff517477) : const Color(0xffbaa478)),
        ),
      );
    }
    // Roof equipment and parapet retain the same perspective as the footprint.
    final top = Offset.lerp(roof[0], roof[2], .5)!;
    c.drawPath(
      _poly([
        top + const Offset(-14, -8),
        top + const Offset(18, 7),
        top + const Offset(18, -8),
        top + const Offset(-14, -23),
      ]),
      _paint(fade(const Color(0xff22393f))),
    );
    c.drawLine(
      top + const Offset(-14, -23),
      top + const Offset(18, -8),
      _paint(fade(const Color(0xff738278)))..strokeWidth = 2,
    );
    if (block.style == 1) {
      final awning = [
        base[3] - const Offset(0, 33),
        base[2] - const Offset(0, 33),
        base[2] + const Offset(0, -24),
        base[3] + const Offset(0, -24),
      ];
      c.drawPath(_poly(awning), _paint(fade(const Color(0xff57867a))));
      for (var j = 0; j < 10; j++) {
        final a = Offset.lerp(awning[0], awning[1], j / 10)!;
        final d = Offset.lerp(awning[3], awning[2], j / 10)!;
        c.drawLine(
          a,
          d,
          _paint(fade(const Color(0xffa9b39a)))..strokeWidth = 3,
        );
      }
    }
    if (block.name.isNotEmpty) {
      final p = Offset.lerp(base[3], base[2], .5)! - const Offset(0, 48);
      _text(
        c,
        block.name,
        p,
        color: const Color(0xffcfceb3),
        fontSize: 9,
        backing: true,
      );
    }
  }

  void _drawTower(Canvas c) {
    final p = iso(29, 3);
    final path = Path()
      ..moveTo(p.dx - 17, p.dy)
      ..lineTo(p.dx, p.dy - 240)
      ..lineTo(p.dx + 17, p.dy);
    c.drawPath(
      path,
      Paint()
        ..color = const Color(0xff5b6d68)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 4,
    );
    for (var i = 0; i < 6; i++) {
      final y = i * 34.0;
      final w = 17 * (1 - y / 240);
      c.drawLine(
        p + Offset(-w, -y),
        p + Offset(w * .8, -y - 31),
        _paint(const Color(0xff3e595a))..strokeWidth = 2,
      );
    }
    final glow = session.reducedEffects
        ? .7
        : .6 + math.sin(session.elapsed * 2) * .25;
    c.drawCircle(
      p - const Offset(0, 240),
      22,
      Paint()
        ..shader = ui.Gradient.radial(p - const Offset(0, 240), 22, [
          Color.fromRGBO(220, 133, 88, glow),
          const Color(0x00d88b60),
        ]),
    );
    c.drawCircle(p - const Offset(0, 240), 3, _paint(const Color(0xffe0a16f)));
  }

  void _lamp(Canvas c, double x, double y) {
    final p = iso(x, y);
    c.drawOval(
      Rect.fromCenter(center: p + const Offset(18, -2), width: 120, height: 54),
      Paint()
        ..shader = ui.Gradient.radial(p + const Offset(18, -2), 65, [
          const Color(0x3ec0a971),
          const Color(0x00b6a371),
        ]),
    );
    c.drawLine(
      p,
      p - const Offset(0, 83),
      _paint(const Color(0xff182f38))..strokeWidth = 4,
    );
    c.drawLine(
      p - const Offset(0, 83),
      p + const Offset(17, -77),
      _paint(const Color(0xff426166))..strokeWidth = 3,
    );
    c.drawRect(
      Rect.fromLTWH(p.dx + 13, p.dy - 79, 12, 4),
      _paint(const Color(0xffdfc58c)),
    );
  }

  void _place(Canvas c, Place place) {
    final p = iso(place.x, place.y);
    switch (place.kind) {
      case PointKind.helena:
        _actor(c, 'helena', place.x, place.y, -1, 1, false);
      case PointKind.neighbor:
        _actor(c, 'neighbor', place.x, place.y, 1, 1, false);
      case PointKind.television:
        _prop(c, 3, p, 64);
        c.drawOval(
          Rect.fromCenter(center: p, width: 74, height: 24),
          _paint(const Color(0x185acab1)),
        );
      case PointKind.panel:
        _prop(c, 2, p, 60);
      case PointKind.bandage:
        _prop(c, 1, p, 44);
      case PointKind.exit:
        c.drawLine(
          p + const Offset(-24, 12),
          p + const Offset(24, -12),
          _paint(session.campaign.canLeave ? teal : const Color(0xffb18561))
            ..strokeWidth = 5,
        );
        for (final d in [-24.0, 24.0]) {
          c.drawLine(
            p + Offset(d, -d / 2),
            p + Offset(d, -d / 2 - 42),
            _paint(const Color(0xff7b9289))..strokeWidth = 4,
          );
        }
    }
    final near = session.world.distance(place.x, place.y) < 3.4;
    final important = session.world.perception || near;
    if (important) {
      final y =
          p.dy -
          (place.kind == PointKind.helena || place.kind == PointKind.neighbor
              ? 80
              : 62);
      _text(
        c,
        place.label.toUpperCase(),
        Offset(p.dx, y),
        color: near ? amber : teal,
        fontSize: 9,
        backing: true,
      );
      c.drawOval(
        Rect.fromCenter(center: p, width: 24, height: 12),
        Paint()
          ..color = (near ? amber : teal).withValues(alpha: .55)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.5,
      );
    }
  }

  void _prop(Canvas c, int index, Offset p, double extent) {
    final image = _sprites['props']!;
    c.drawImageRect(
      image,
      Rect.fromLTWH(index * 64.0, 0, 64, 64),
      Rect.fromLTWH(p.dx - extent / 2, p.dy - extent + 5, extent, extent),
      Paint()..filterQuality = FilterQuality.none,
    );
  }

  void _actor(
    Canvas c,
    String name,
    double x,
    double y,
    double dx,
    double dy,
    bool moving,
  ) {
    final p = iso(x, y);
    c.drawOval(
      Rect.fromCenter(center: p, width: 25, height: 12),
      _paint(const Color(0x73202c2e)),
    );
    final screenDX = dx - dy, screenDY = (dx + dy) / 2;
    final angle = math.atan2(screenDY, screenDX);
    if (name == 'dominated') {
      final direction = ((angle / (math.pi / 4)).round() + 2) % 8;
      final frame = moving ? ((session.elapsed * 7).floor() % 4) : 0;
      c.drawImageRect(
        _sprites[name]!,
        Rect.fromLTWH(frame * 32.0, direction * 48.0, 32, 48),
        Rect.fromLTWH(p.dx - 24, p.dy - 69, 48, 72),
        Paint(),
      );
    } else {
      var key = 'user_$name';
      var mirror = false;
      if (name == 'caio') {
        if (moving) {
          final directions = ['E', 'SE', 'S', 'SW', 'W', 'NW', 'N', 'NE'];
          var facing = directions[(angle / (math.pi / 4)).round() % 8];
          mirror = facing == 'E';
          if (mirror) facing = 'W';
          key = 'user_caio_${facing}_${(session.elapsed * 8).floor() % 6}';
        } else {
          key = 'user_caio_idle';
        }
      }
      c.save();
      c.translate(p.dx, p.dy);
      if (mirror) c.scale(-1, 1);
      c.drawImageRect(
        _sprites[key]!,
        const Rect.fromLTWH(0, 0, 128, 128),
        const Rect.fromLTWH(-40, -75, 80, 80),
        Paint()..filterQuality = FilterQuality.low,
      );
      c.restore();
    }
    if (name == 'caio' && session.world.pushCooldown > .4) {
      c.drawOval(
        Rect.fromCenter(center: p, width: 105, height: 52),
        Paint()
          ..color = const Color(0x99c2b58c)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2,
      );
    }
  }

  void _enemy(Canvas c) {
    final world = session.world;
    final p = iso(world.enemyX, world.enemyY);
    if (world.distance(world.enemyX, world.enemyY) < 5) {
      c.drawOval(
        Rect.fromCenter(center: p, width: 35, height: 17),
        Paint()
          ..color = const Color(0x99c7806b)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.5,
      );
    }
    _actor(
      c,
      'dominated',
      world.enemyX,
      world.enemyY,
      session.campaign.x - world.enemyX,
      session.campaign.y - world.enemyY,
      world.enemyStun <= 0,
    );
    _text(
      c,
      world.enemyStun > 0 ? 'DESORIENTADO' : 'MORADOR EM CRISE',
      p - const Offset(0, 77),
      color: const Color(0xffd6a28b),
      fontSize: 8,
      backing: true,
    );
  }

  void _text(
    Canvas c,
    String value,
    Offset p, {
    Color color = teal,
    double fontSize = 10,
    bool backing = false,
  }) {
    final key = '$value:$fontSize:${color.toARGB32()}';
    final text = _labels.putIfAbsent(
      key,
      () => TextPainter(
        text: TextSpan(
          text: value,
          style: TextStyle(
            color: color,
            fontSize: fontSize,
            fontWeight: FontWeight.w700,
            letterSpacing: 1,
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout(),
    );
    final origin = p - Offset(text.width / 2, text.height / 2);
    if (backing) {
      c.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(
            origin.dx - 6,
            origin.dy - 4,
            text.width + 12,
            text.height + 8,
          ),
          const Radius.circular(3),
        ),
        _paint(const Color(0xd91a2c32)),
      );
    }
    text.paint(c, origin);
  }

  void _rain(Canvas c) {
    if (session.reducedEffects) return;
    final paint = Paint()
      ..color = const Color(0x294f969b)
      ..strokeWidth = 1;
    for (var i = 0; i < 65; i++) {
      final x = ((i * 137.3 - session.elapsed * 52) % (size.x + 30)) - 15;
      final y = (i * 89.7 + session.elapsed * 235) % (size.y + 30) - 15;
      c.drawLine(Offset(x, y), Offset(x - 5, y + 15), paint);
    }
  }

  @override
  void onRemove() {
    _ground?.dispose();
    for (final painter in _labels.values) {
      painter.dispose();
    }
    super.onRemove();
  }
}
