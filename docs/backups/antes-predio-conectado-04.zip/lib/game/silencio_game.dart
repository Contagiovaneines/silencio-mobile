import 'dart:math' as math;
import 'dart:convert';
import 'dart:async';

import 'package:flutter/services.dart';

import '../services/game_audio.dart';
import 'sprite_facing.dart';

import 'dart:ui' as ui;

import 'package:flame/game.dart';
import 'package:flame/cache.dart';
import 'package:flutter/painting.dart';

import '../models/campaign.dart';
import 'game_session.dart';
import 'world_model.dart';

class SilencioGame extends FlameGame {
  SilencioGame(this.session, {this.enableAudio = false}) {
    images = Images();
  }
  final bool enableAudio;
  final GameAudio audio = GameAudio();
  final GameSession session;
  final Map<String, ui.Image> _sprites = {};
  final Map<String, TextPainter> _labels = {};
  final Map<String, Rect> _furnitureSources = {};
  final Map<int, ui.Picture> _grounds = {};
  int _cameraFloor = 2;
  bool _ready = false, _disposed = false;
  double _cameraX = 0, _cameraY = 0;
  double get zoom => (size.y / 560).clamp(.78, 1.35);
  static const ink = Color(0xff102029);
  static const teal = Color(0xff91beb1);
  static const amber = Color(0xffdfb477);

  Offset iso(double x, double y) => Offset((x - y) * 32, (x + y) * 16);

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    if (!await _loadSprite('props', 'props.png')) return;
    for (final direction in ['N', 'NE', 'SE', 'S', 'SW', 'W', 'NW']) {
      for (var frame = 0; frame < 6; frame++) {
        final key = 'user_caio_${direction}_$frame';
        if (!await _loadSprite(key, '$key.png')) return;
      }
    }
    final manifest = jsonDecode(
      await rootBundle.loadString('assets/data/phase_assets.json'),
    ) as Map<String, dynamic>;
    for (final entry in manifest.entries) {
      if (!await _loadSprite(entry.key, entry.value as String)) return;
    }
    final furnitureData = jsonDecode(
      await rootBundle.loadString('assets/data/apartment_furniture.json'),
    ) as Map<String, dynamic>;
    for (final entry
        in (furnitureData['sprites'] as Map<String, dynamic>).entries) {
      final values = (entry.value as List).cast<num>();
      _furnitureSources[entry.key] = Rect.fromLTWH(
        values[0].toDouble(),
        values[1].toDouble(),
        values[2].toDouble(),
        values[3].toDouble(),
      );
    }
    for (final floor in [0, 2]) {
      final recorder = ui.PictureRecorder();
      _drawGround(Canvas(recorder), floor: floor);
      _grounds[floor] = recorder.endRecording();
    }
    _cameraFloor = session.campaign.floor;
    final p = iso(session.campaign.x, session.campaign.y);
    _cameraX = p.dx;
    _cameraY = p.dy;
    _ready = true;
  }

  Future<bool> _loadSprite(String key, String path) async {
    if (_disposed) return false;
    final image = await images.load(path);
    if (_disposed) return false;
    _sprites[key] = image;
    return true;
  }

  @override
  void update(double dt) {
    super.update(dt);
    session.tick(dt);
    if (enableAudio) audio.update(session);
    final p = iso(session.campaign.x, session.campaign.y);
    if (_cameraFloor != session.campaign.floor) {
      _cameraFloor = session.campaign.floor;
      _cameraX = p.dx;
      _cameraY = p.dy;
    }
    final blend = 1 - math.exp(-dt * 7);
    _cameraX += (p.dx - _cameraX) * blend;
    _cameraY += (p.dy - _cameraY) * blend;
  }

  void tapGround(Offset screen) {
    if (session.phase != PlayPhase.playing) return;
    final local =
        (screen - Offset(size.x * .5, size.y * .53)) / zoom +
        Offset(_cameraX, _cameraY);
    final x = (local.dx / 32 + local.dy / 16) / 2;
    final y = (local.dy / 16 - local.dx / 32) / 2;
    session.world.moveTo(x, y);
  }

  Paint _paint(Color color) => Paint()..color = color;
  Path _poly(List<Offset> points) => Path()..addPolygon(points, true);

  void _drawGround(Canvas c, {required int floor}) {
    for (var y = 0; y < WorldModel.height; y++) {
      for (var x = 0; x < WorldModel.width; x++) {
        if (floor == 2 && !(x >= 2 && x < 12 && y >= 2 && y < 16)) continue;
        if (floor == 0 && y < 16 && !(x >= 12 && x < 23 && y >= 10)) continue;
        final apartment = floor == 2 && x >= 2 && x < 12 && y >= 2 && y < 10;
        final hall = x >= 2 && x < 12 && y >= 10 && y < 16;
        final garage = x >= 12 && x < 23 && y >= 10 && y < 16;
        final shop = x >= 24 && x < 32 && y >= 17 && y < 24;
        final road = y >= 26 && y <= 30 || x >= 43 && x < 50 && y >= 16;
        final plaza = x >= 15 && x < 26 && y >= 27 && y < 36;
        final tile = apartment
            ? 'wood'
            : hall || garage || shop || plaza
            ? 'concrete'
            : road
            ? 'asphalt'
            : y >= 16
            ? 'sidewalk'
            : 'grass';
        final p = iso(x.toDouble(), y.toDouble());
        c.drawImageRect(
          _sprites['tile_$tile']!,
          const Rect.fromLTWH(0, 0, 64, 32),
          Rect.fromLTWH(p.dx - 32, p.dy, 64, 32),
          Paint()..color = const Color(0xffa5b1aa),
        );
        c.drawPath(
          _poly([
            p,
            p + const Offset(32, 16),
            p + const Offset(0, 32),
            p + const Offset(-32, 16),
          ]),
          Paint()..color = Color.fromRGBO(7, 25, 32, apartment ? .16 : .28),
        );
        if (road && y == 28 && x % 3 == 0) {
          c.drawLine(
            p + const Offset(-8, 12),
            p + const Offset(15, 23),
            _paint(const Color(0xffb5a26b))..strokeWidth = 2,
          );
        }
      }
    }
  }

  @override
  void render(Canvas canvas) {
    super.render(canvas);
    final c = canvas;
    c.drawRect(Rect.fromLTWH(0, 0, size.x, size.y), _paint(ink));
    if (!_ready) return;
    c.save();
    c.translate(size.x * .5, size.y * .53);
    c.scale(zoom);
    c.translate(-_cameraX, -_cameraY);
    c.drawPicture(_grounds[session.campaign.floor]!);
    if (session.campaign.floor == 0) {
      _drawTower(c);
    } else {
      _upperLanding(c);
    }

    _drawPath(c);
    final draws =
        <
          ({
            double depth,
            void Function() draw,
            Rect? footprint,
            Offset? position,
          })
        >[];
    for (final block in session.world.visibleBlocks) {
      draws.add((
        depth: block.interior
            ? block.bounds.left + block.bounds.top
            : block.bounds.right + block.bounds.bottom,
        footprint: block.interior ? null : block.bounds,
        position: null,
        draw: () => _building(c, block),
      ));
    }
    for (final p
        in session.campaign.floor == 0
            ? [
                const Offset(7, 18),
                const Offset(21, 18.5),
                const Offset(26, 12),
              ]
            : <Offset>[]) {
      draws.add((
        depth: p.dx + p.dy,
        footprint: null,
        position: p,
        draw: () => _lamp(c, p.dx, p.dy),
      ));
    }
    for (final place in session.world.places) {
      draws.add((
        depth: place.x + place.y,
        footprint: null,
        position: Offset(place.x, place.y),
        draw: () => _place(c, place),
      ));
    }
    for (final person in session.world.people) {
      draws.add((
        depth: person.x + person.y,
        footprint: null,
        position: Offset(person.x, person.y),
        draw: () => _actor(c, person.id, person.x, person.y, 1, 1, false),
      ));
    }
    for (final vehicle in session.world.visibleVehicles) {
      draws.add((
        depth: vehicle.position.dx + vehicle.position.dy,
        footprint: vehicle.bounds,
        position: null,
        draw: () => _vehicle(c, vehicle),
      ));
    }
    for (final furniture in session.world.visibleFurniture) {
      final b = furniture.bounds;
      draws.add((
        depth: b.center.dx + b.center.dy,
        footprint: b,
        position: null,
        draw: () => _furniture(c, furniture),
      ));
    }
    final player = session.campaign;
    draws.add((
      depth: player.x + player.y,
      footprint: null,
      position: Offset(player.x, player.y),
      draw: () {
        if (session.phase == PlayPhase.transit) return;
        _actor(
          c,
          'caio',
          player.x,
          player.y,
          session.world.facingX,
          session.world.facingY,
          session.world.moving || session.phase == PlayPhase.buildingTransition,
        );
      },
    ));
    if (session.world.encounterActive) {
      draws.add((
        depth: session.world.enemyX + session.world.enemyY,
        footprint: null,
        position: Offset(session.world.enemyX, session.world.enemyY),
        draw: () => _enemy(c),
      ));
    }
    draws.sort((a, b) => a.depth.compareTo(b.depth));
    // A building spans several tiles: its far corner alone cannot order actors.
    // Constrain only overlapping projected footprints, then draw ready nodes by depth.
    final edges = List.generate(draws.length, (_) => <int>{});
    final incoming = List.filled(draws.length, 0);
    for (var i = 0; i < draws.length; i++) {
      final bounds = draws[i].footprint;
      if (bounds == null) continue;
      for (var j = 0; j < draws.length; j++) {
        final point = draws[j].position;
        if (point == null) continue;
        final projectedX = point.dx - point.dy;
        if (projectedX < bounds.left - bounds.bottom ||
            projectedX > bounds.right - bounds.top) {
          continue;
        }
        final inFront = point.dy >= bounds.bottom || point.dx >= bounds.right;
        final from = inFront ? i : j;
        final to = inFront ? j : i;
        if (edges[from].add(to)) incoming[to]++;
      }
    }
    final remaining = List.generate(draws.length, (i) => i);
    while (remaining.isNotEmpty) {
      final index = remaining.firstWhere(
        (i) => incoming[i] == 0,
        orElse: () => remaining.first,
      );
      remaining.remove(index);
      draws[index].draw();
      for (final next in edges[index]) {
        incoming[next]--;
      }
    }
    if (session.phase != PlayPhase.buildingTransition) {
      for (final place in session.world.places) {
        _placeLabel(c, place);
      }
    }
    if (session.world.perception) {
      final center = iso(player.x, player.y);
      c.drawOval(
        Rect.fromCenter(center: center, width: 290, height: 145),
        Paint()
          ..color = const Color(0x554bd1c0)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2,
      );
    }
    c.restore();
    if (session.campaign.floor == 0) _rain(c);
    final vignette = ui.Gradient.radial(
      Offset(size.x * .5, size.y * .5),
      size.x * .65,
      [const Color(0x00102029), const Color(0x85102029)],
      [.35, 1],
    );
    c.drawRect(Rect.fromLTWH(0, 0, size.x, size.y), Paint()..shader = vignette);
  }

  void _drawPath(Canvas c) {
    if (session.world.path.isEmpty) return;
    for (var i = 0; i < session.world.path.length; i += 2) {
      final point = session.world.path[i];
      c.drawOval(
        Rect.fromCenter(center: iso(point.dx, point.dy), width: 5, height: 3),
        _paint(const Color(0x6595c4b5)),
      );
    }
    final last = session.world.path.last;
    c.drawOval(
      Rect.fromCenter(center: iso(last.dx, last.dy), width: 23, height: 11),
      Paint()
        ..color = const Color(0xaa95c4b5)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.5,
    );
  }

  void _building(Canvas c, Block block) {
    if (block.interior) {
      _room(c, block);
      return;
    }
    final b = block.bounds;
    final base = [
      iso(b.left, b.top),
      iso(b.right, b.top),
      iso(b.right, b.bottom),
      iso(b.left, b.bottom),
    ];
    final roof = base.map((p) => p - Offset(0, block.height)).toList();
    final behind =
        session.campaign.y < b.top &&
        session.campaign.y > b.top - 4 &&
        session.campaign.x > b.left - 2 &&
        session.campaign.x < b.right + 2;
    final alpha = behind ? .5 : 1.0;
    Color fade(Color color) => color.withValues(alpha: alpha);
    c.drawPath(
      _poly(base.map((p) => p + const Offset(14, 10)).toList()),
      _paint(const Color(0x49202c2c)),
    );
    c.drawPath(
      _poly([base[3], base[2], roof[2], roof[3]]),
      _paint(fade(const Color(0xff23383f))),
    );
    c.drawPath(
      _poly([base[1], base[2], roof[2], roof[1]]),
      _paint(fade(const Color(0xff334b50))),
    );
    c.drawPath(
      _poly(roof),
      _paint(
        fade(
          block.style == 1 ? const Color(0xff49615d) : const Color(0xff344e51),
        ),
      ),
    );
    c.drawPath(
      _poly(roof),
      Paint()
        ..color = fade(const Color(0xff6b7a70))
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.5,
    );
    for (var floor = 0; floor < (block.height / 32).floor(); floor++) {
      final up = 18.0 + floor * 30;
      for (var j = 1; j < 6; j++) {
        final p = Offset.lerp(base[3], base[2], j / 6)! - Offset(0, up);
        c.drawPath(
          _poly([
            p,
            p + const Offset(12, 6),
            p + const Offset(12, -6),
            p + const Offset(0, -12),
          ]),
          _paint(
            fade(
              (j + floor) % 4 == 0
                  ? const Color(0xffab9266)
                  : const Color(0xff142d36),
            ),
          ),
        );
      }
    }
    for (var j = 1; j < 5; j++) {
      final p = Offset.lerp(base[1], base[2], j / 5)! - const Offset(0, 34);
      c.drawPath(
        _poly([
          p,
          p + const Offset(-13, 6),
          p + const Offset(-13, -10),
          p + const Offset(0, -16),
        ]),
        _paint(
          fade(j.isEven ? const Color(0xff517477) : const Color(0xffbaa478)),
        ),
      );
    }
    // Roof equipment and parapet retain the same perspective as the footprint.
    final top = Offset.lerp(roof[0], roof[2], .5)!;
    c.drawPath(
      _poly([
        top + const Offset(-14, -8),
        top + const Offset(18, 7),
        top + const Offset(18, -8),
        top + const Offset(-14, -23),
      ]),
      _paint(fade(const Color(0xff22393f))),
    );
    c.drawLine(
      top + const Offset(-14, -23),
      top + const Offset(18, -8),
      _paint(fade(const Color(0xff738278)))..strokeWidth = 2,
    );
    if (block.style == 1) {
      final awning = [
        base[3] - const Offset(0, 33),
        base[2] - const Offset(0, 33),
        base[2] + const Offset(0, -24),
        base[3] + const Offset(0, -24),
      ];
      c.drawPath(_poly(awning), _paint(fade(const Color(0xff57867a))));
      for (var j = 0; j < 10; j++) {
        final a = Offset.lerp(awning[0], awning[1], j / 10)!;
        final d = Offset.lerp(awning[3], awning[2], j / 10)!;
        c.drawLine(
          a,
          d,
          _paint(fade(const Color(0xffa9b39a)))..strokeWidth = 3,
        );
      }
    }
    if (block.name.isNotEmpty) {
      final p = Offset.lerp(base[3], base[2], .5)! - const Offset(0, 48);
      _text(
        c,
        block.name,
        p,
        color: const Color(0xffcfceb3),
        fontSize: 9,
        backing: true,
      );
    }
  }

  void _drawTower(Canvas c) {
    final p = iso(52, 18);
    final path = Path()
      ..moveTo(p.dx - 17, p.dy)
      ..lineTo(p.dx, p.dy - 240)
      ..lineTo(p.dx + 17, p.dy);
    c.drawPath(
      path,
      Paint()
        ..color = const Color(0xff5b6d68)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 4,
    );
    for (var i = 0; i < 6; i++) {
      final y = i * 34.0;
      final w = 17 * (1 - y / 240);
      c.drawLine(
        p + Offset(-w, -y),
        p + Offset(w * .8, -y - 31),
        _paint(const Color(0xff3e595a))..strokeWidth = 2,
      );
    }
    final glow = session.reducedEffects
        ? .7
        : .6 + math.sin(session.elapsed * 2) * .25;
    c.drawCircle(
      p - const Offset(0, 240),
      22,
      Paint()
        ..shader = ui.Gradient.radial(p - const Offset(0, 240), 22, [
          Color.fromRGBO(220, 133, 88, glow),
          const Color(0x00d88b60),
        ]),
    );
    c.drawCircle(p - const Offset(0, 240), 3, _paint(const Color(0xffe0a16f)));
  }

  void _lamp(Canvas c, double x, double y) {
    final p = iso(x, y);
    c.drawOval(
      Rect.fromCenter(center: p + const Offset(18, -2), width: 120, height: 54),
      Paint()
        ..shader = ui.Gradient.radial(p + const Offset(18, -2), 65, [
          const Color(0x3ec0a971),
          const Color(0x00b6a371),
        ]),
    );
    c.drawLine(
      p,
      p - const Offset(0, 83),
      _paint(const Color(0xff182f38))..strokeWidth = 4,
    );
    c.drawLine(
      p - const Offset(0, 83),
      p + const Offset(17, -77),
      _paint(const Color(0xff426166))..strokeWidth = 3,
    );
    c.drawRect(
      Rect.fromLTWH(p.dx + 13, p.dy - 79, 12, 4),
      _paint(const Color(0xffdfc58c)),
    );
  }

  void _upperLanding(Canvas c) {
    final a = iso(2, 16), b = iso(12, 16);
    c.drawPath(
      _poly([a, b, b + const Offset(0, 42), a + const Offset(0, 42)]),
      _paint(const Color(0xff202e36)),
    );
    for (var i = 0; i < 16; i++) {
      final p = Offset.lerp(a, b, i / 16)!;
      c.drawLine(
        p,
        p + const Offset(0, 42),
        _paint(const Color(0xff39464a))..strokeWidth = 1,
      );
    }
    final wallA = iso(2, 10), wallB = iso(2, 16);
    c.drawPath(
      _poly([
        wallA,
        wallB,
        wallB - const Offset(0, 65),
        wallA - const Offset(0, 65),
      ]),
      _paint(const Color(0xff4d5656)),
    );
    final p = iso(2.08, 12.1);
    c.drawPath(
      _poly([
        p,
        p + const Offset(-29, 14),
        p + const Offset(-29, -37),
        p - const Offset(0, 51),
      ]),
      _paint(const Color(0xff74604a)),
    );
    _text(c, '202', p + const Offset(-14, -24), fontSize: 9, color: amber);
    _text(
      c,
      '2º ANDAR · ESCADAS',
      iso(8, 15.6) - const Offset(0, 5),
      fontSize: 9,
      color: teal,
      backing: true,
    );
  }

  void _apartmentDoor(Canvas c) {
    const x = 6.1, y = 10.0, width = 1.8, height = 62.0;
    final angle = (session.buildingTransition?.doorAngle ?? 0) * math.pi / 2;
    final a = iso(x, y), b = iso(x + width, y);
    c.drawLine(
      a,
      a - const Offset(0, height + 5),
      _paint(const Color(0xffba9b70))..strokeWidth = 5,
    );
    c.drawLine(
      b,
      b - const Offset(0, height + 5),
      _paint(const Color(0xffba9b70))..strokeWidth = 5,
    );
    c.drawLine(
      a - const Offset(0, height + 5),
      b - const Offset(0, height + 5),
      _paint(const Color(0xffba9b70))..strokeWidth = 5,
    );
    final q = iso(x + math.cos(angle) * width, y - math.sin(angle) * width);
    c.drawPath(
      _poly([a, q, q - const Offset(0, height), a - const Offset(0, height)]),
      _paint(const Color(0xff715037)),
    );
    for (var i = 1; i < 5; i++) {
      final p = Offset.lerp(a, q, i / 5)!;
      c.drawLine(
        p - const Offset(0, 3),
        p - const Offset(0, height - 3),
        _paint(const Color(0xff8d6543))..strokeWidth = 1,
      );
    }
    final handle = Offset.lerp(a, q, .82)! - const Offset(0, 29);
    c.drawCircle(handle, 2.2, _paint(const Color(0xffe4bf77)));
    _text(
      c,
      '203',
      Offset.lerp(a, q, .5)! - const Offset(0, 45),
      fontSize: 10,
      color: amber,
      backing: true,
    );
  }

  void _staircase(Canvas c, Offset position, bool ascending) {
    for (var i = 7; i >= 0; i--) {
      final y = position.dy + i * .22,
          drop = ascending ? -(7 - i) * 5.0 : i * 5.0;
      final a = iso(position.dx - .7, y) + Offset(0, drop),
          b = iso(position.dx + .7, y) + Offset(0, drop);
      final d = iso(position.dx + .7, y + .22) + Offset(0, drop),
          e = iso(position.dx - .7, y + .22) + Offset(0, drop);
      c.drawPath(
        _poly([a, b, d, e]),
        _paint(i.isEven ? const Color(0xff77817c) : const Color(0xff606f6d)),
      );
      c.drawLine(e, d, _paint(const Color(0xffadb1a0))..strokeWidth = 1);
    }
    final a = iso(position.dx + .8, position.dy) - const Offset(0, 35),
        b =
            iso(position.dx + .8, position.dy + 1.8) +
            Offset(0, ascending ? -35 : 0);
    c.drawLine(a, b, _paint(const Color(0xffb3aa91))..strokeWidth = 3);
    _text(
      c,
      ascending ? 'SUBIR · 2º ANDAR' : 'DESCER · TÉRREO',
      iso(position.dx, position.dy) - const Offset(0, 58),
      fontSize: 8,
      color: amber,
      backing: true,
    );
  }

  void _elevator(Canvas c) {
    final p = iso(3.3, 13.8);
    final frame = Rect.fromLTWH(p.dx - 25, p.dy - 72, 50, 72);
    c.drawRRect(
      RRect.fromRectAndRadius(frame, const Radius.circular(3)),
      _paint(const Color(0xff273b43)),
    );
    c.drawRect(frame.deflate(5), _paint(const Color(0xff77817e)));
    c.drawLine(
      p - const Offset(0, 67),
      p - const Offset(0, 4),
      _paint(ink)..strokeWidth = 2,
    );
    _text(
      c,
      'MANUTENÇÃO',
      p - const Offset(0, 34),
      fontSize: 7,
      color: amber,
      backing: true,
    );
    _text(c, '2', p - const Offset(0, 82), fontSize: 12, color: amber);
  }

  void _room(Canvas c, Block block) {
    final b = block.bounds;
    final a = iso(b.left, b.top),
        d = iso(b.right, b.top),
        e = iso(b.left, b.bottom);
    final h = block.height;
    c.drawPath(
      _poly([a, d, d - Offset(0, h), a - Offset(0, h)]),
      _paint(
        block.style == 3 ? const Color(0xff817568) : const Color(0xff556c6a),
      ),
    );
    c.drawPath(
      _poly([a, e, e - Offset(0, h), a - Offset(0, h)]),
      _paint(
        block.style == 3 ? const Color(0xff665d54) : const Color(0xff394f53),
      ),
    );
    for (var i = 1; block.style != 4 && i < 4; i++) {
      final w = Offset.lerp(a, d, i / 4)! - Offset(0, h * .6);
      final frame = Rect.fromCenter(center: w, width: 20, height: 25);
      c.drawRect(
        frame,
        _paint(
          block.style == 3 ? const Color(0xff44382c) : const Color(0xff8eaaa1),
        ),
      );
      if (block.style == 3) {
        c.drawRect(frame.deflate(3), _paint(const Color(0xff2b4343)));
        c.drawLine(
          w + const Offset(-6, 4),
          w + const Offset(0, -5),
          _paint(const Color(0xffb5a481))..strokeWidth = 1.5,
        );
        c.drawLine(
          w + const Offset(0, -5),
          w + const Offset(6, 4),
          _paint(const Color(0xff81977f))..strokeWidth = 1.5,
        );
      }
    }
    if (block.style == 3) {
      final a = iso(2.02, 4), b = iso(2.02, 6.5);
      final window = [
        a - const Offset(0, 18),
        b - const Offset(0, 18),
        b - const Offset(0, 50),
        a - const Offset(0, 50),
      ];
      c.drawPath(_poly(window), _paint(const Color(0xffdec390)));
      c.drawPath(
        _poly(window),
        Paint()
          ..color = const Color(0xffad9070)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 4,
      );
      for (var i = 1; i < 5; i++) {
        final p = Offset.lerp(window[0], window[3], i / 5)!;
        final q = Offset.lerp(window[1], window[2], i / 5)!;
        c.drawLine(p, q, _paint(const Color(0xff9e7c53))..strokeWidth = 1);
      }
      final beam = [iso(2.3, 4), iso(2.3, 6.5), iso(6.5, 6.5), iso(6.5, 4)];
      c.drawPath(_poly(beam), Paint()..color = const Color(0x28edba71));
      final rug = [iso(5.2, 6), iso(7.9, 6), iso(7.9, 7.7), iso(5.2, 7.7)];
      c.drawPath(_poly(rug), _paint(const Color(0xff776b55)));
      c.drawPath(
        _poly(rug),
        Paint()
          ..color = const Color(0xffc2ab78)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2,
      );
    }
    final left = iso(b.left, b.bottom),
        right = iso(b.right, b.bottom),
        doorL = iso(b.center.dx - .9, b.bottom),
        doorR = iso(b.center.dx + .9, b.bottom);
    for (final edge in [(left, doorL), (doorR, right)]) {
      c.drawPath(
        _poly([
          edge.$1,
          edge.$2,
          edge.$2 - const Offset(0, 14),
          edge.$1 - const Offset(0, 14),
        ]),
        _paint(const Color(0xff526963)),
      );
    }
    _text(
      c,
      block.name,
      iso(b.center.dx, b.top) - Offset(0, h + 12),
      fontSize: 10,
      color: amber,
    );
    if (block.style == 3) {
      final p = iso(6.5, 4);

      c.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromCenter(
            center: p - const Offset(0, 21),
            width: 7,
            height: 12,
          ),
          const Radius.circular(1),
        ),
        _paint(teal),
      );
    }
  }

  void _furniture(Canvas c, Furnishing furniture) {
    final b = furniture.bounds, h = furniture.height, kind = furniture.kind;
    final source = _furnitureSources[kind];
    if (session.campaign.floor == 2 && source != null) {
      final image = _sprites['apartment_furniture']!;
      final width = (b.width + b.height) * 32 * 1.18;
      final height = width * source.height / source.width;
      final center = iso(b.center.dx, b.center.dy);
      final bottom = iso(b.right, b.bottom).dy;
      c.drawOval(
        Rect.fromCenter(
          center: center + const Offset(0, 5),
          width: width * .75,
          height: 22,
        ),
        _paint(const Color(0x45201913)),
      );
      final destination = Rect.fromLTWH(
        center.dx - width / 2,
        bottom - height,
        width,
        height,
      );
      final actor =
          iso(session.campaign.x, session.campaign.y) - const Offset(0, 35);
      final occludes =
          destination.contains(actor) &&
          session.campaign.x + session.campaign.y < b.right + b.bottom;
      c.drawImageRect(
        image,
        source,
        destination,
        Paint()
          ..filterQuality = FilterQuality.medium
          ..color = Color.fromRGBO(255, 255, 255, occludes ? .45 : 1),
      );
      return;
    }
    final top = [
      iso(b.left, b.top),
      iso(b.right, b.top),
      iso(b.right, b.bottom),
      iso(b.left, b.bottom),
    ];
    final color = kind == 'bed'
        ? const Color(0xffa1a48b)
        : kind == 'fridge'
        ? const Color(0xffa5b2aa)
        : kind == 'sofa'
        ? const Color(0xff4e7975)
        : kind == 'shelf'
        ? const Color(0xff867c64)
        : const Color(0xff8d8b74);
    c.drawPath(
      _poly([top[3], top[2], top[2] - Offset(0, h), top[3] - Offset(0, h)]),
      _paint(Color.lerp(color, ink, .45)!),
    );
    c.drawPath(
      _poly([top[1], top[2], top[2] - Offset(0, h), top[1] - Offset(0, h)]),
      _paint(Color.lerp(color, ink, .25)!),
    );
    c.drawPath(_poly(top.map((p) => p - Offset(0, h)).toList()), _paint(color));
    if (kind == 'bed') {
      c.drawLine(
        top[0] - Offset(0, h),
        top[1] - Offset(0, h),
        _paint(const Color(0xffdedbc5))..strokeWidth = 10,
      );
      c.drawLine(
        Offset.lerp(top[0], top[3], .7)! - Offset(0, h),
        Offset.lerp(top[1], top[2], .7)! - Offset(0, h),
        _paint(const Color(0xff567b78))..strokeWidth = 14,
      );
    } else if (kind == 'shelf') {
      for (var level = 1; level < 4; level++) {
        final a = top[3] - Offset(0, level * h / 4),
            z = top[2] - Offset(0, level * h / 4);
        c.drawLine(a, z, _paint(const Color(0xffc4b58a))..strokeWidth = 2);
        for (var i = 1; i < 5; i++) {
          final p = Offset.lerp(a, z, i / 5)!;
          c.drawLine(
            p,
            p - const Offset(0, 7),
            _paint(i.isEven ? teal : amber)..strokeWidth = 4,
          );
        }
      }
    } else if (kind == 'sofa') {
      c.drawLine(
        top[0] - Offset(0, h + 9),
        top[1] - Offset(0, h + 9),
        _paint(const Color(0xff668d82))..strokeWidth = 12,
      );
      c.drawLine(
        top[3] - Offset(0, h),
        top[0] - Offset(0, h + 4),
        _paint(const Color(0xff395b57))..strokeWidth = 6,
      );
    } else if (kind == 'fridge') {
      final p = Offset.lerp(top[2], top[3], .7)!;
      c.drawLine(
        p - Offset(0, h * .65),
        p - Offset(0, h * .4),
        _paint(ink)..strokeWidth = 2,
      );
      c.drawLine(
        top[2] - Offset(0, h * .6),
        top[3] - Offset(0, h * .6),
        _paint(const Color(0xff718e85))..strokeWidth = 1,
      );
    } else if (kind == 'kitchen') {
      final p = iso(b.center.dx, b.center.dy) - Offset(0, h);
      c.drawOval(Rect.fromCenter(center: p, width: 21, height: 9), _paint(ink));
      c.drawArc(
        Rect.fromCenter(center: p - const Offset(0, 7), width: 10, height: 12),
        math.pi,
        math.pi,
        false,
        _paint(teal)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2,
      );
    } else if (kind == 'bench') {
      for (var i = 1; i < 4; i++) {
        c.drawLine(
          Offset.lerp(top[0], top[3], i / 4)! - Offset(0, h),
          Offset.lerp(top[1], top[2], i / 4)! - Offset(0, h),
          _paint(const Color(0xff544a40))..strokeWidth = 1,
        );
      }
    }
  }

  void _vehicle(Canvas c, Vehicle vehicle) {
    final open =
        vehicle.id == 'sedan' && session.campaign.has('loot') ||
        vehicle.id == 'bus' && session.phase == PlayPhase.transit;
    final image =
        _sprites['vehicle_${vehicle.id}_${open ? 'open' : 'closed'}']!;
    final offset = vehicle.id == 'bus' && session.phase == PlayPhase.transit
        ? Offset(session.sceneTime * 8, session.sceneTime * 4)
        : Offset.zero;
    final p = iso(vehicle.position.dx, vehicle.position.dy) + offset;
    final w = vehicle.width, h = w * image.height / image.width;
    c.drawImageRect(
      image,
      Rect.fromLTWH(0, 0, image.width.toDouble(), image.height.toDouble()),
      Rect.fromLTWH(p.dx - w / 2, p.dy - h * .96, w, h),
      Paint()..filterQuality = FilterQuality.low,
    );
    if (vehicle.id == 'bus' && session.phase == PlayPhase.transit) {
      _text(
        c,
        'CAIO · EMBARCADO',
        p - Offset(0, h + 5),
        fontSize: 9,
        color: amber,
      );
    }
  }

  void _place(Canvas c, Place place) {
    final p = iso(place.x, place.y);
    switch (place.kind) {
      case PointKind.apartmentDoor:
        _apartmentDoor(c);
      case PointKind.stairsDown:
        _staircase(c, const Offset(10, 14), false);
      case PointKind.stairsUp:
        _staircase(c, const Offset(13.2, 14.2), true);
      case PointKind.elevator:
        _elevator(c);

      case PointKind.television:
        _prop(c, 3, p, 48);
      case PointKind.panel:
        _prop(c, 2, p, 32);
      case PointKind.adapter:
      case PointKind.key:
      case PointKind.water:
        final name = place.kind == PointKind.adapter
            ? 'adapter'
            : place.kind == PointKind.key
            ? 'key'
            : 'water';
        final image = _sprites['item_$name'];
        if (image != null) {
          c.drawImageRect(
            image,
            Rect.fromLTWH(
              0,
              0,
              image.width.toDouble(),
              image.height.toDouble(),
            ),
            Rect.fromLTWH(p.dx - 14, p.dy - 24, 28, 28),
            Paint(),
          );
        } else {
          c.drawCircle(p - const Offset(0, 8), 5, _paint(amber));
        }
      case PointKind.gate:
        final a = iso(40.9, 24), b = iso(40.9, 27.8);
        if (!session.campaign.has('resolved')) {
          for (var i = 0; i <= 7; i++) {
            final q = Offset.lerp(a, b, i / 7)!;
            c.drawLine(
              q,
              q - const Offset(0, 38),
              _paint(const Color(0xff88938b))..strokeWidth = 2,
            );
          }
          c.drawLine(
            a - const Offset(0, 28),
            b - const Offset(0, 28),
            _paint(teal)..strokeWidth = 3,
          );
        }
      case PointKind.dog:
      case PointKind.cat:
      case PointKind.pigeon:
        final name = place.kind == PointKind.dog
            ? 'fuba'
            : place.kind == PointKind.cat
            ? 'breu'
            : 'pingo';
        final time = session.world.simulationTime;
        final frame =
            name == 'breu' || name == 'fuba' && !session.world.dogMoving
            ? 0
            : (time * 4).floor() % 6;
        final image = _sprites['animal_${name}_$frame']!;
        final flight = name == 'pingo'
            ? math.sin((session.world.birdFlight / 4) * math.pi) * 35
            : 0.0;
        final lift = name == 'breu' ? 26.0 : 0.0;
        c.drawImageRect(
          image,
          const Rect.fromLTWH(0, 0, 96, 96),
          Rect.fromLTWH(p.dx - 25, p.dy - 46 - flight - lift, 50, 50),
          Paint()..filterQuality = FilterQuality.low,
        );
      default:
        break;
    }
  }

  void _placeLabel(Canvas c, Place place) {
    final p = iso(place.x, place.y);
    final near = session.world.distance(place.x, place.y) < 3;
    if (near || session.world.perception) {
      c.drawOval(
        Rect.fromCenter(center: p, width: 23, height: 11),
        Paint()
          ..color = amber.withValues(alpha: .7)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.4,
      );
      _text(
        c,
        place.label.toUpperCase(),
        p - const Offset(0, 80),
        fontSize: 8,
        color: amber,
        backing: true,
      );
    }
  }

  void _prop(Canvas c, int index, Offset p, double extent) {
    final image = _sprites['props']!;
    c.drawImageRect(
      image,
      Rect.fromLTWH(index * 64.0, 0, 64, 64),
      Rect.fromLTWH(p.dx - extent / 2, p.dy - extent + 5, extent, extent),
      Paint()..filterQuality = FilterQuality.none,
    );
  }

  void _actor(
    Canvas c,
    String name,
    double x,
    double y,
    double dx,
    double dy,
    bool moving,
  ) {
    final p =
        iso(x, y) +
        Offset(
          0,
          name == 'caio' ? (session.buildingTransition?.actorDrop ?? 0) : 0,
        );
    c.drawOval(
      Rect.fromCenter(center: p, width: 25, height: 12),
      _paint(const Color(0x73202c2e)),
    );
    if (name != 'caio' && name != 'dominated') {
      final image = _sprites['phase_$name']!;
      c.drawImageRect(
        image,
        const Rect.fromLTWH(0, 0, 128, 128),
        Rect.fromLTWH(p.dx - 40, p.dy - 75, 80, 80),
        Paint()..filterQuality = FilterQuality.low,
      );
      return;
    }
    if (name == 'dominated') {
      final image = _sprites['phase_davi']!;
      c.save();
      c.translate(p.dx, p.dy);
      final threat = session.world.attackWindup > 0;
      c.rotate(
        threat
            ? -.09
            : session.world.enemyStun > 0
            ? .1
            : math.sin(session.elapsed * 7) * .015,
      );
      c.drawImageRect(
        image,
        const Rect.fromLTWH(0, 0, 128, 128),
        const Rect.fromLTWH(-40, -75, 80, 80),
        Paint()..filterQuality = FilterQuality.low,
      );
      c.restore();
      if (threat) {
        c.drawArc(
          Rect.fromCenter(center: p, width: 60, height: 30),
          0,
          math.pi * 2 * (1 - session.world.attackWindup / .65),
          false,
          Paint()
            ..color = const Color(0xffda9b74)
            ..style = PaintingStyle.stroke
            ..strokeWidth = 3,
        );
      }
      return;
    }
    final facing = SpriteFacing.fromWorld(
      dx,
      dy,
      running: moving && session.world.running,
    );
    final action = session.phase == PlayPhase.defeated
        ? 'defeat'
        : session.world.action;
    var state = 'idle';
    if (action == 'push') {
      final progress =
          1 - session.world.actionTime / session.world.actionDuration;
      state = progress < .35
          ? 'push_anticipation'
          : progress < .65
          ? 'push_contact'
          : 'push_recover';
    } else if (action == 'heal') {
      state = 'heal_pose';
    } else if (action == 'pickup') {
      state = 'pickup_pose';
    } else if (action == 'hurt') {
      state = 'hurt';
    } else if (action == 'defeat') {
      state = 'defeat_pose';
    }
    final frame = (session.world.walked / .27).floor() % 6;
    final key = moving && state == 'idle'
        ? (session.world.running
              ? 'run_${facing.source}_$frame'
              : 'user_caio_${facing.source}_$frame')
        : 'pose_${facing.source}_$state';
    final image = _sprites[key]!;
    c.save();
    c.translate(p.dx, p.dy);
    if (facing.mirror) c.scale(-1, 1);
    c.drawImageRect(
      image,
      const Rect.fromLTWH(0, 0, 128, 128),
      const Rect.fromLTWH(-40, -75, 80, 80),
      Paint()..filterQuality = FilterQuality.low,
    );
    c.restore();
    if (name == 'caio' && session.world.pushCooldown > .4) {
      c.drawOval(
        Rect.fromCenter(center: p, width: 105, height: 52),
        Paint()
          ..color = const Color(0x99c2b58c)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2,
      );
    }
  }

  void _enemy(Canvas c) {
    final world = session.world;
    final p = iso(world.enemyX, world.enemyY);
    if (world.distance(world.enemyX, world.enemyY) < 5) {
      c.drawOval(
        Rect.fromCenter(center: p, width: 35, height: 17),
        Paint()
          ..color = const Color(0x99c7806b)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.5,
      );
    }
    _actor(
      c,
      'dominated',
      world.enemyX,
      world.enemyY,
      session.campaign.x - world.enemyX,
      session.campaign.y - world.enemyY,
      world.enemyStun <= 0,
    );
    _text(
      c,
      world.enemyStun > 0 ? 'DESORIENTADO' : 'MORADOR EM CRISE',
      p - const Offset(0, 77),
      color: const Color(0xffd6a28b),
      fontSize: 8,
      backing: true,
    );
  }

  void _text(
    Canvas c,
    String value,
    Offset p, {
    Color color = teal,
    double fontSize = 10,
    bool backing = false,
  }) {
    final key = '$value:$fontSize:${color.toARGB32()}';
    final text = _labels.putIfAbsent(
      key,
      () => TextPainter(
        text: TextSpan(
          text: value,
          style: TextStyle(
            color: color,
            fontSize: fontSize,
            fontWeight: FontWeight.w700,
            letterSpacing: 1,
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout(),
    );
    final origin = p - Offset(text.width / 2, text.height / 2);
    if (backing) {
      c.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(
            origin.dx - 6,
            origin.dy - 4,
            text.width + 12,
            text.height + 8,
          ),
          const Radius.circular(3),
        ),
        _paint(const Color(0xd91a2c32)),
      );
    }
    text.paint(c, origin);
  }

  void _rain(Canvas c) {
    if (session.reducedEffects) return;
    final paint = Paint()
      ..color = const Color(0x294f969b)
      ..strokeWidth = 1;
    for (var i = 0; i < 65; i++) {
      final x = ((i * 137.3 - session.elapsed * 52) % (size.x + 30)) - 15;
      final y = (i * 89.7 + session.elapsed * 235) % (size.y + 30) - 15;
      c.drawLine(Offset(x, y), Offset(x - 5, y + 15), paint);
    }
  }

  @override
  void onDispose() {
    _disposed = true;
    _ready = false;
    unawaited(audio.dispose());
    for (final ground in _grounds.values) {
      ground.dispose();
    }
    _grounds.clear();
    for (final painter in _labels.values) {
      painter.dispose();
    }
    _labels.clear();
    _sprites.clear();
    images.clearCache();
    super.onDispose();
  }
}
