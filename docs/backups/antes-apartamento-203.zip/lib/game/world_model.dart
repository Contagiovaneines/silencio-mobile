import 'dart:collection';
import 'dart:math' as math;
import 'dart:ui';

import '../models/campaign.dart';

enum PointKind {
  phone,
  key,
  adapter,
  neighbor,
  merchant,
  television,
  panel,
  sedan,
  water,
  gate,
  bus,
  crossing,
  bed,
  dog,
  cat,
  pigeon,
}

class Place {
  const Place(this.kind, this.x, this.y, this.label, this.action);
  final PointKind kind;
  final double x, y;
  final String label, action;
}

class Block {
  const Block(
    this.bounds,
    this.name,
    this.style,
    this.height, {
    this.interior = false,
  });
  final Rect bounds;
  final String name;
  final int style;
  final double height;
  final bool interior;
}

class Furnishing {
  const Furnishing(this.bounds, this.kind, this.height);
  final Rect bounds;
  final String kind;
  final double height;
}

class Person {
  const Person(this.id, this.x, this.y);
  final String id;
  final double x, y;
}

class Vehicle {
  const Vehicle(this.id, this.position, this.bounds, this.width);
  final String id;
  final Offset position;
  final Rect bounds;
  final double width;
}

class WorldModel {
  WorldModel(this.campaign);
  Campaign campaign;
  static const width = 56, height = 44, radius = .22;
  static const blocks = [
    Block(
      Rect.fromLTRB(2, 2, 12, 10),
      'APARTAMENTO · CAIO',
      3,
      54,
      interior: true,
    ),
    Block(
      Rect.fromLTRB(24, 17, 32, 24),
      'MERCEARIA · ORLANDO',
      1,
      65,
      interior: true,
    ),
    Block(Rect.fromLTRB(3, 19, 10, 25), 'RESIDENCIAL AURORA', 0, 105),
    Block(Rect.fromLTRB(33, 17, 41, 23), 'OFICINA', 2, 72),
    Block(Rect.fromLTRB(4, 31, 12, 38), 'CASAS DA PRAÇA', 0, 88),
    Block(Rect.fromLTRB(35, 34, 43, 40), 'CENTRAL', 2, 100),
  ];
  static const vehicles = [
    Vehicle(
      'sedan',
      Offset(19, 13),
      Rect.fromLTRB(17.4, 12.2, 20.5, 13.6),
      145,
    ),
    Vehicle('van', Offset(35, 28), Rect.fromLTRB(33.4, 27.2, 36.6, 28.7), 155),
    Vehicle('bus', Offset(47, 32), Rect.fromLTRB(44.2, 30.7, 49.6, 32.7), 245),
  ];
  static const furniture = [
    Furnishing(Rect.fromLTRB(3, 3, 5.4, 5), 'bed', 16),
    Furnishing(Rect.fromLTRB(9, 3, 11, 4.4), 'kitchen', 24),
    Furnishing(Rect.fromLTRB(9.6, 7, 11, 8.7), 'shelf', 48),
    Furnishing(Rect.fromLTRB(3, 7.5, 4.8, 9), 'sofa', 23),
    Furnishing(Rect.fromLTRB(24.5, 17.7, 26, 20.5), 'shelf', 48),
    Furnishing(Rect.fromLTRB(29.7, 17.8, 31.4, 19.2), 'fridge', 57),
    Furnishing(Rect.fromLTRB(30, 21, 31.5, 22.7), 'counter', 23),
    Furnishing(Rect.fromLTRB(18.5, 27, 20, 28), 'bench', 14),
    Furnishing(Rect.fromLTRB(23, 30.5, 24.5, 31.5), 'bench', 14),
    Furnishing(Rect.fromLTRB(5.7, 3.4, 7, 4.2), 'table', 18),
  ];
  List<Person> get people => [
    const Person('ines', 8, 12.5),
    if (campaign.has('alley') && !campaign.has('resolved'))
      const Person('orlando', 36, 25)
    else
      const Person('orlando', 28, 22),
    const Person('nestor', 45, 29.5),
    const Person('marina', 22, 29.5),
    const Person('bia', 22.8, 29.8),
    if (campaign.has('resolved')) const Person('davi', 38, 25),
  ];
  List<Place> get places => [
    const Place(PointKind.phone, 6.5, 4, 'Celular', 'Ler mensagem'),
    if (!campaign.has('key'))
      const Place(PointKind.key, 9, 4.7, 'Chave de casa', 'Pegar chave'),
    if (!campaign.has('adapter'))
      const Place(PointKind.adapter, 10.3, 6.5, 'Adaptador', 'Recolher'),
    const Place(PointKind.bed, 4.3, 5.5, 'Cama · salvar o dia', 'Descansar'),
    const Place(PointKind.neighbor, 8, 12.5, 'Dona Inês', 'Ajudar'),
    Place(PointKind.merchant, people[1].x, people[1].y, 'Orlando', 'Conversar'),
    const Place(
      PointKind.television,
      30.4,
      19.8,
      'TV da mercearia',
      'Ver notícia',
    ),
    const Place(PointKind.panel, 25.2, 21, 'Tomada queimada', 'Examinar'),
    const Place(PointKind.sedan, 19, 14.3, 'Sedã · porta-malas', 'Abrir'),
    if (!campaign.has('water'))
      const Place(PointKind.water, 29.4, 22.5, 'Água', 'Recolher'),
    const Place(PointKind.gate, 40.5, 26.2, 'Portão · alavanca', 'Acionar'),
    const Place(PointKind.bus, 45, 29.5, 'Nestor · ônibus', 'Embarcar'),
    const Place(PointKind.crossing, 48.5, 28, 'Passagem a pé', 'Seguir a pé'),
    Place(PointKind.dog, dogX, dogY, 'Fubá', 'Observar'),
    const Place(PointKind.cat, 7.5, 25.6, 'Breu na janela', 'Observar'),
    const Place(PointKind.pigeon, 21, 28, 'Pingo', 'Observar'),
  ];
  double simulationTime = 0, dogX = 17, dogY = 15;
  bool dogMoving = false;
  double inputX = 0,
      inputY = 0,
      enemyX = 38,
      enemyY = 26.5,
      enemyStun = 0,
      attackCooldown = 0,
      pushCooldown = 0;
  double enemyKnockX = 0, enemyKnockY = 0, facingX = 1, facingY = 0, walked = 0;
  double actionTime = 0,
      actionDuration = 0,
      attackWindup = 0,
      encounterTime = 0,
      stepTimer = 0,
      birdFlight = 0;
  String action = 'idle';
  bool actionContact = false, perception = false, running = false;
  final path = <Offset>[];
  final sounds = <String>[];
  bool get encounterActive =>
      campaign.has('alley') && !campaign.has('resolved');
  bool get moving =>
      action == 'idle' && (inputX != 0 || inputY != 0 || path.isNotEmpty);
  double distance(double x, double y) =>
      math.sqrt(math.pow(x - campaign.x, 2) + math.pow(y - campaign.y, 2));
  Iterable<Rect> get walls sync* {
    for (final block in blocks) {
      final b = block.bounds;
      if (!block.interior) {
        yield b;
        continue;
      }
      const t = .18;
      final middle = b.center.dx;
      yield Rect.fromLTRB(b.left - t, b.top - t, b.right + t, b.top + t);
      yield Rect.fromLTRB(b.left - t, b.top, b.left + t, b.bottom);
      yield Rect.fromLTRB(b.right - t, b.top, b.right + t, b.bottom);
      yield Rect.fromLTRB(b.left, b.bottom - t, middle - .9, b.bottom + t);
      yield Rect.fromLTRB(middle + .9, b.bottom - t, b.right, b.bottom + t);
    }
    yield* furniture.map((f) => f.bounds);
    yield* vehicles.map((v) => v.bounds);
    if (!campaign.has('resolved')) {
      yield const Rect.fromLTRB(40.8, 24, 41.05, 27.8);
    }
  }

  bool isOpen(double x, double y) {
    if (x < 2.4 || x > 52 || y < 2.4 || y > 39.5) return false;
    final floor =
        y >= 16 ||
        const Rect.fromLTRB(2, 2, 12, 16).contains(Offset(x, y)) ||
        const Rect.fromLTRB(12, 10, 23, 16.3).contains(Offset(x, y));
    if (!floor) return false;
    if (y > 9.6 && y < 10.4 && x < 12 && !campaign.has('key')) return false;
    final body = Rect.fromCircle(center: Offset(x, y), radius: radius);
    return !walls.any((b) => b.overlaps(body));
  }

  bool canStand(double x, double y, {bool enemy = false}) {
    if (!isOpen(x, y)) return false;
    if ((Offset(x, y) - Offset(dogX, dogY)).distance < .44) return false;
    for (final p in people) {
      if ((Offset(x, y) - Offset(p.x, p.y)).distance < .58) return false;
    }
    if (!enemy &&
        encounterActive &&
        (Offset(x, y) - Offset(enemyX, enemyY)).distance < .56) {
      return false;
    }
    if (enemy &&
        (Offset(x, y) - Offset(campaign.x, campaign.y)).distance < .6) {
      return false;
    }
    return true;
  }

  Place? get nearby {
    Place? nearest;
    var d = 1.85;
    for (final p in places) {
      final next = distance(p.x, p.y);
      if (next < d) {
        d = next;
        nearest = p;
      }
    }
    return nearest;
  }

  void restore(Campaign value) {
    campaign = value;
    inputX = inputY = 0;
    path.clear();
    enemyX = 38;
    enemyY = 26.5;
    enemyStun = attackCooldown = pushCooldown = attackWindup = encounterTime =
        0;
    enemyKnockX = enemyKnockY = 0;
    action = 'idle';
    simulationTime = 0;
    dogX = 17;
    dogY = 15;
    dogMoving = false;
    actionTime = 0;
    perception = running = false;
    sounds.clear();
    if (!canStand(value.x, value.y)) {
      campaign.x = 6;
      campaign.y = 6;
    }
  }

  void setInput(double x, double y) {
    inputX = x;
    inputY = y;
    if (x != 0 || y != 0) path.clear();
  }

  void moveTo(double x, double y) {
    if (action != 'idle') return;
    var goal = (x.floor(), y.floor());
    if (!canStand(goal.$1 + .5, goal.$2 + .5)) {
      final candidates = <((int, int), double)>[];
      for (var a = -2; a <= 2; a++) {
        for (var b = -2; b <= 2; b++) {
          final gx = goal.$1 + a, gy = goal.$2 + b;
          if (canStand(gx + .5, gy + .5)) {
            candidates.add((
              (gx, gy),
              math.pow(gx + .5 - x, 2).toDouble() +
                  math.pow(gy + .5 - y, 2).toDouble(),
            ));
          }
        }
      }
      if (candidates.isEmpty) return;
      candidates.sort((a, b) => a.$2.compareTo(b.$2));
      goal = candidates.first.$1;
    }
    final start = (campaign.x.floor(), campaign.y.floor());
    final queue = Queue<(int, int)>()..add(start);
    final previous = <(int, int), (int, int)?>{start: null};
    while (queue.isNotEmpty) {
      final here = queue.removeFirst();
      if (here == goal) break;
      for (final s in [(1, 0), (-1, 0), (0, 1), (0, -1)]) {
        final n = (here.$1 + s.$1, here.$2 + s.$2);
        final from = here == start
            ? Offset(campaign.x, campaign.y)
            : Offset(here.$1 + .5, here.$2 + .5);
        if (previous.containsKey(n) ||
            !canStand(n.$1 + .5, n.$2 + .5) ||
            !canTravel(from, Offset(n.$1 + .5, n.$2 + .5))) {
          continue;
        }
        previous[n] = here;
        queue.add(n);
      }
    }
    if (!previous.containsKey(goal)) return;
    final reverse = <Offset>[];
    (int, int)? n = goal;
    while (n != null && n != start) {
      reverse.add(Offset(n.$1 + .5, n.$2 + .5));
      n = previous[n];
    }
    path
      ..clear()
      ..addAll(reverse.reversed);
  }

  bool canTravel(Offset from, Offset to) {
    final steps = ((to - from).distance / .1).ceil();
    for (var i = 1; i <= steps; i++) {
      final p = Offset.lerp(from, to, i / steps)!;
      if (!canStand(p.dx, p.dy)) return false;
    }
    return true;
  }

  bool lineClear(Offset from, Offset to) {
    final distance = (to - from).distance;
    final count = (distance / .1).ceil();
    for (var i = 1; i < count; i++) {
      final p = Offset.lerp(from, to, i / count)!;
      if (!isOpen(p.dx, p.dy)) return false;
    }
    return true;
  }

  void beginAction(String value, double duration) {
    action = value;
    actionDuration = actionTime = duration;
    actionContact = false;
    path.clear();
    setInput(0, 0);
  }

  void update(double delta) {
    var remaining = delta.clamp(0.0, .12);
    while (remaining > 0) {
      final dt = math.min(remaining, 1 / 60);
      _step(dt);
      remaining -= dt;
    }
  }

  void _step(double dt) {
    simulationTime += dt;
    final dog = Offset(
      17 + math.sin(simulationTime * .4) * 1.2,
      15 + math.sin(simulationTime * .8) * .15,
    );
    dogMoving =
        isOpen(dog.dx, dog.dy) &&
        (dog - Offset(campaign.x, campaign.y)).distance > .65;
    if (dogMoving) {
      dogX = dog.dx;
      dogY = dog.dy;
    }

    pushCooldown = math.max(0, pushCooldown - dt);
    attackCooldown = math.max(0, attackCooldown - dt);
    enemyStun = math.max(0, enemyStun - dt);
    birdFlight = math.max(0, birdFlight - dt);
    if (action != 'idle') {
      actionTime = math.max(0, actionTime - dt);
      if (!actionContact && actionTime <= actionDuration * .55) {
        actionContact = true;
        if (action == 'push') {
          sounds.add('push');
          final delta = Offset(enemyX - campaign.x, enemyY - campaign.y);
          if (encounterActive &&
              delta.distance > 0 &&
              delta.distance < 1.8 &&
              (delta.dx * facingX + delta.dy * facingY) / delta.distance >
                  .35 &&
              lineClear(
                Offset(campaign.x, campaign.y),
                Offset(enemyX, enemyY),
              )) {
            enemyStun = 1.5;
            enemyKnockX = delta.dx / delta.distance * 5;
            enemyKnockY = delta.dy / delta.distance * 5;
          }
        }
        if (action == 'heal' && campaign.bandages > 0) {
          campaign.bandages--;
          campaign.health = math.min(100, campaign.health + 35);
          campaign.injured = false;
          sounds.add('heal');
        }
      }
      if (actionTime == 0) action = 'idle';
    }
    var dx = action == 'idle' ? inputX : 0.0,
        dy = action == 'idle' ? inputY : 0.0;
    if (dx == 0 && dy == 0 && path.isNotEmpty && action == 'idle') {
      final n = path.first;
      dx = n.dx - campaign.x;
      dy = n.dy - campaign.y;
      if (math.sqrt(dx * dx + dy * dy) < .08) {
        path.removeAt(0);
        dx = dy = 0;
      }
    }
    final length = math.sqrt(dx * dx + dy * dy);
    if (length > 0) {
      dx /= length;
      dy /= length;
      facingX = dx;
      facingY = dy;
      final fast = running && campaign.stamina > 5;
      final step = (fast ? 4.3 : 2.65) * dt;
      final old = Offset(campaign.x, campaign.y);
      if (canStand(campaign.x + dx * step, campaign.y)) campaign.x += dx * step;
      if (canStand(campaign.x, campaign.y + dy * step)) campaign.y += dy * step;
      final traveled = (Offset(campaign.x, campaign.y) - old).distance;
      walked += traveled;
      stepTimer += traveled;
      if (stepTimer > .8) {
        stepTimer = 0;
        sounds.add('step');
      }
      if (traveled < .001 && path.isNotEmpty) path.clear();
      if (fast) campaign.stamina = math.max(0, campaign.stamina - 17 * dt);
      if (fast && distance(21, 28) < 4 && birdFlight == 0) {
        birdFlight = 4;
        sounds.add('bird');
      }
    }
    if (perception) {
      campaign.stamina = math.max(0, campaign.stamina - 12 * dt);
      if (campaign.stamina == 0) perception = false;
    } else if (!running || length == 0) {
      campaign.stamina = math.min(100, campaign.stamina + 12 * dt);
    }
    if (campaign.has('delivered') &&
        campaign.has('news') &&
        !campaign.has('alley') &&
        campaign.x > 32 &&
        campaign.y < 30 &&
        campaign.y > 23) {
      campaign.mark('alley');
      sounds.add('alert');
    }
    if (!encounterActive) return;
    encounterTime += dt;
    if (encounterTime > 3 && distance(enemyX, enemyY) > 5 && campaign.x > 40) {
      campaign.mark('resolved');
      sounds.add('door');
      return;
    }
    if (enemyStun > 0) {
      final nx = enemyX + enemyKnockX * dt, ny = enemyY + enemyKnockY * dt;
      if (canStand(nx, enemyY, enemy: true)) enemyX = nx;
      if (canStand(enemyX, ny, enemy: true)) enemyY = ny;
      enemyKnockX *= math.pow(.03, dt);
      enemyKnockY *= math.pow(.03, dt);
      return;
    }
    final ex = campaign.x - enemyX,
        ey = campaign.y - enemyY,
        dist = math.sqrt(ex * ex + ey * ey);
    if (attackWindup > 0) {
      attackWindup = math.max(0, attackWindup - dt);
      if (attackWindup == 0) {
        attackCooldown = 1.6;
        if (dist < 1.25 &&
            lineClear(Offset(enemyX, enemyY), Offset(campaign.x, campaign.y))) {
          campaign.health = math.max(0, campaign.health - 12);
          campaign.injured = true;
          beginAction('hurt', .4);
          sounds.add('hit');
        }
      }
      return;
    }
    if (dist < 1.1 &&
        attackCooldown == 0 &&
        lineClear(Offset(enemyX, enemyY), Offset(campaign.x, campaign.y))) {
      attackWindup = .65;
      return;
    }
    if (dist < 7 && dist > .8) {
      final step = 1.25 * dt;
      if (canStand(enemyX + ex / dist * step, enemyY, enemy: true)) {
        enemyX += ex / dist * step;
      }
      if (canStand(enemyX, enemyY + ey / dist * step, enemy: true)) {
        enemyY += ey / dist * step;
      }
    }
  }

  bool push() {
    if (action != 'idle' || pushCooldown > 0 || campaign.stamina < 22) {
      return false;
    }
    campaign.stamina -= 22;
    pushCooldown = .8;
    beginAction('push', .65);
    return true;
  }

  bool heal() {
    if (action != 'idle' ||
        encounterActive && distance(enemyX, enemyY) < 5 ||
        campaign.bandages == 0 ||
        campaign.health >= 100 && !campaign.injured) {
      return false;
    }
    beginAction('heal', 1.6);
    return true;
  }
}
