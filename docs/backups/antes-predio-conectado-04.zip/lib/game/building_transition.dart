import 'dart:math' as math;
import 'dart:ui';

import 'world_model.dart';

enum BuildingJourney { leaveApartment, enterApartment, downstairs, upstairs }

/// Owns the temporary pose and floor change; only the final landing is saved.
class BuildingTransition {
  BuildingTransition(this.kind, this.start);
  final BuildingJourney kind;
  final Offset start;
  double elapsed = 0;
  bool _changedFloor = false;
  bool get isDoor =>
      kind == BuildingJourney.leaveApartment ||
      kind == BuildingJourney.enterApartment;
  double get duration => isDoor ? 2.2 : 3.2;
  double get progress => (elapsed / duration).clamp(0, 1);
  String get caption => switch (kind) {
    BuildingJourney.leaveApartment => 'Saindo do apartamento 203 · 2º andar',
    BuildingJourney.enterApartment => 'Entrando no apartamento 203 · 2º andar',
    BuildingJourney.downstairs =>
      progress < .45
          ? 'Descendo · 2º ao 1º andar'
          : 'Descendo · 1º andar ao térreo',
    BuildingJourney.upstairs =>
      progress < .45
          ? 'Subindo · térreo ao 1º andar'
          : 'Subindo · 1º ao 2º andar',
  };
  double get fade => isDoor ? 0 : (1 - (progress - .5).abs() / .16).clamp(0, 1);
  double get doorAngle {
    if (!isDoor) return 0;
    if (elapsed < .4) return 0;
    if (elapsed < 1) return (elapsed - .4) / .6;
    if (elapsed < 1.8) return 1;
    return (1 - (elapsed - 1.8) / .4).clamp(0, 1);
  }

  double get actorDrop {
    if (isDoor) return 0;
    final direction = kind == BuildingJourney.downstairs ? 1.0 : -1.0;
    return progress < .5
        ? direction * progress * 50
        : -direction * (1 - progress) * 50;
  }

  bool advance(double dt, WorldModel world) {
    elapsed = math.min(duration, elapsed + dt);
    final before = Offset(world.campaign.x, world.campaign.y);
    final oldFloor = world.campaign.floor;
    late Offset next;
    if (isDoor) {
      final out = kind == BuildingJourney.leaveApartment;
      final approach = Offset(7, out ? 9.15 : 10.85);
      final exit = Offset(7, out ? 10.85 : 9.15);
      if (elapsed < .4) {
        next = Offset.lerp(start, approach, elapsed / .4)!;
      } else if (elapsed < 1) {
        next = approach;
      } else if (elapsed < 1.8) {
        next = Offset.lerp(approach, exit, (elapsed - 1) / .8)!;
      } else {
        next = exit;
      }
      world.doorOpen = doorAngle > .1;
    } else {
      final down = kind == BuildingJourney.downstairs;
      final firstEnd = down ? const Offset(10, 15.2) : const Offset(13.2, 14.2);
      final secondStart = down
          ? const Offset(13.2, 14.2)
          : const Offset(10, 15.2);
      final landing = down ? const Offset(14, 16.5) : const Offset(10, 13.5);
      if (progress < .5) {
        next = Offset.lerp(start, firstEnd, progress * 2)!;
      } else {
        if (!_changedFloor) {
          world.changeFloor(down ? 0 : 2, secondStart);
          _changedFloor = true;
        }
        next = Offset.lerp(secondStart, landing, (progress - .5) * 2)!;
      }
    }
    world.campaign.x = next.dx;
    world.campaign.y = next.dy;
    final delta = next - before;
    if (oldFloor == world.campaign.floor && delta.distance > .001) {
      world.walked += delta.distance;
      world.facingX = delta.dx / delta.distance;
      world.facingY = delta.dy / delta.distance;
    }
    if (elapsed >= duration) {
      world.doorOpen = false;
      return true;
    }
    return false;
  }
}
