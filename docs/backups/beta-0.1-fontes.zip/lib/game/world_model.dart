import 'dart:collection';
import 'dart:math' as math;
import 'dart:ui';

import '../models/campaign.dart';

enum PointKind { helena, television, panel, neighbor, bandage, exit }

class Place {
  const Place(this.kind, this.x, this.y, this.label, this.action);
  final PointKind kind;
  final double x, y;
  final String label, action;
}

class Block {
  const Block(this.bounds, this.name, this.style, this.height);
  final Rect bounds;
  final String name;
  final int style;
  final double height;
}

class WorldModel {
  WorldModel(this.campaign);
  Campaign campaign;
  static const width = 32;
  static const height = 26;
  static const radius = .23;
  static const blocks = [
    Block(Rect.fromLTRB(7, 5, 13, 11), 'RESIDENCIAL AURORA', 0, 110),
    Block(Rect.fromLTRB(18, 5, 25, 11), 'MERCEARIA · 24H', 1, 72),
    Block(Rect.fromLTRB(2, 18, 7, 23), 'OFICINA', 2, 65),
    Block(Rect.fromLTRB(22, 20, 29, 25), 'CENTRAL', 2, 95),
    Block(Rect.fromLTRB(2, 2, 5, 9), '', 0, 85),
  ];
  static const places = [
    Place(PointKind.helena, 15.5, 14, 'Helena', 'Conversar'),
    Place(PointKind.television, 19, 12.2, 'TV da mercearia', 'Ver notícia'),
    Place(PointKind.panel, 13.8, 10.6, 'Quadro elétrico', 'Investigar'),
    Place(PointKind.neighbor, 8.4, 12.4, 'Moradora', 'Oferecer ajuda'),
    Place(PointKind.bandage, 10, 19.1, 'Kit de primeiros socorros', 'Recolher'),
    Place(PointKind.exit, 28, 14.8, 'Passagem leste', 'Atravessar'),
  ];

  double inputX = 0, inputY = 0;
  double enemyX = 23, enemyY = 17;
  double enemyStun = 0, attackCooldown = 0, pushCooldown = 0;
  double enemyKnockX = 0, enemyKnockY = 0;
  double facingX = 1, facingY = 0;
  bool perception = false;
  double walked = 0;
  final List<Offset> path = [];

  double distance(double x, double y) =>
      math.sqrt(math.pow(x - campaign.x, 2) + math.pow(y - campaign.y, 2));

  bool isOpen(double x, double y) {
    if (x < 1 || x > 30 || y < 1 || y > 24) return false;
    final body = Rect.fromCircle(center: Offset(x, y), radius: radius);
    return !blocks.any((block) => block.bounds.overlaps(body));
  }

  Place? get nearby {
    Place? result;
    var nearest = 1.9;
    for (final place in places) {
      if (place.kind == PointKind.bandage && campaign.pickedBandage) continue;
      final d = distance(place.x, place.y);
      if (d < nearest) {
        nearest = d;
        result = place;
      }
    }
    return result;
  }

  void restore(Campaign value) {
    campaign = value;
    if (!isOpen(value.x, value.y)) {
      campaign.x = 12;
      campaign.y = 17;
    }
    inputX = inputY = 0;
    path.clear();
    enemyX = 23;
    enemyY = 17;
    enemyStun = attackCooldown = pushCooldown = 0;
    enemyKnockX = enemyKnockY = 0;
    perception = false;
  }

  void setInput(double x, double y) {
    inputX = x;
    inputY = y;
    if (x != 0 || y != 0) path.clear();
  }

  void moveTo(double x, double y) {
    final start = (campaign.x.floor(), campaign.y.floor());
    final goal = (x.floor(), y.floor());
    if (!isOpen(goal.$1 + .5, goal.$2 + .5)) return;
    final queue = Queue<(int, int)>()..add(start);
    final previous = <(int, int), (int, int)?>{start: null};
    while (queue.isNotEmpty) {
      final current = queue.removeFirst();
      if (current == goal) break;
      for (final step in [(1, 0), (-1, 0), (0, 1), (0, -1)]) {
        final next = (current.$1 + step.$1, current.$2 + step.$2);
        if (previous.containsKey(next) || !isOpen(next.$1 + .5, next.$2 + .5)) {
          continue;
        }
        previous[next] = current;
        queue.add(next);
      }
    }
    if (!previous.containsKey(goal)) return;
    final reversed = <Offset>[];
    (int, int)? current = goal;
    while (current != null && current != start) {
      reversed.add(Offset(current.$1 + .5, current.$2 + .5));
      current = previous[current];
    }
    path
      ..clear()
      ..addAll(reversed.reversed);
  }

  void update(double delta) {
    // Clamp long frames; collision is evaluated at each normal simulation step.
    final dt = delta.clamp(0.0, .04);
    pushCooldown = math.max(0, pushCooldown - dt);
    attackCooldown = math.max(0, attackCooldown - dt);
    enemyStun = math.max(0, enemyStun - dt);
    var dx = inputX, dy = inputY;
    if (dx == 0 && dy == 0 && path.isNotEmpty) {
      final next = path.first;
      dx = next.dx - campaign.x;
      dy = next.dy - campaign.y;
      if (math.sqrt(dx * dx + dy * dy) < .12) {
        path.removeAt(0);
        dx = dy = 0;
      }
    }
    final length = math.sqrt(dx * dx + dy * dy);
    if (length > 0) {
      dx /= length;
      dy /= length;
      facingX = dx;
      facingY = dy;
      final step = 2.9 * dt;
      if (isOpen(campaign.x + dx * step, campaign.y)) campaign.x += dx * step;
      if (isOpen(campaign.x, campaign.y + dy * step)) campaign.y += dy * step;
      walked += step;
    }
    if (perception) {
      campaign.stamina = math.max(0, campaign.stamina - 16 * dt);
      if (campaign.stamina == 0) perception = false;
    } else {
      campaign.stamina = math.min(100, campaign.stamina + 14 * dt);
    }
    if (!campaign.inspectedPanel || campaign.finished) return;
    if (enemyStun > 0) {
      final nx = enemyX + enemyKnockX * dt;
      final ny = enemyY + enemyKnockY * dt;
      if (isOpen(nx, enemyY)) enemyX = nx;
      if (isOpen(enemyX, ny)) enemyY = ny;
      enemyKnockX *= math.pow(.03, dt);
      enemyKnockY *= math.pow(.03, dt);
      return;
    }
    final ex = campaign.x - enemyX, ey = campaign.y - enemyY;
    final ed = math.sqrt(ex * ex + ey * ey);
    if (ed < 7 && ed > .65) {
      final step = 1.35 * dt;
      if (isOpen(enemyX + ex / ed * step, enemyY)) enemyX += ex / ed * step;
      if (isOpen(enemyX, enemyY + ey / ed * step)) enemyY += ey / ed * step;
    }
    if (ed < .85 && attackCooldown <= 0) {
      campaign.health = math.max(0, campaign.health - 9);
      attackCooldown = 1.5;
    }
  }

  bool push() {
    if (pushCooldown > 0 || campaign.stamina < 22) return false;
    campaign.stamina -= 22;
    pushCooldown = .75;
    var dx = enemyX - campaign.x, dy = enemyY - campaign.y;
    final d = math.sqrt(dx * dx + dy * dy);
    if (d > 2.4 || d == 0) return true;
    dx /= d;
    dy /= d;
    enemyKnockX = dx * 6;
    enemyKnockY = dy * 6;
    enemyStun = 1.6;
    return true;
  }
}
