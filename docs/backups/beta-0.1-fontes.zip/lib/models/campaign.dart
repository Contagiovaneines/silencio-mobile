import 'dart:convert';

enum PlayPhase {
  menu,
  playing,
  dialogue,
  news,
  journal,
  paused,
  complete,
  defeated,
}

class JournalEntry {
  const JournalEntry(this.id, this.title, this.text, this.kind);
  final String id;
  final String title;
  final String text;
  final String kind;
}

class DialogueLine {
  const DialogueLine(this.id, this.speaker, this.mode, this.text);
  final String id;
  final String speaker;
  final String mode;
  final String text;
  Map<String, String> toJson() => {
    'id': id,
    'speaker': speaker,
    'mode': mode,
    'text': text,
  };

  factory DialogueLine.fromJson(Map<String, dynamic> value) {
    final fields = ['id', 'speaker', 'mode', 'text'];
    if (fields.any((key) => value[key] is! String)) {
      throw const FormatException('Fala sem identificação ou texto.');
    }
    final line = DialogueLine(
      value['id'],
      value['speaker'],
      value['mode'],
      value['text'],
    );
    if (line.speaker == 'CAIO' &&
        !['celular', 'escrita', 'gesto', 'Libras'].contains(line.mode)) {
      throw const FormatException('Caio se comunica sem fala vocal.');
    }
    return line;
  }
}

class Campaign {
  double x = 12;
  double y = 17;
  double health = 100;
  double stamina = 100;
  bool metHelena = false;
  bool readNews = false;
  bool inspectedPanel = false;
  bool helpedNeighbor = false;
  bool pickedBandage = false;
  bool finished = false;
  int bandages = 1;
  String choice = '';
  final List<DialogueLine> history = [];

  bool get canLeave => metHelena && readNews && inspectedPanel;
  int get evidenceCount =>
      [metHelena, readNews, inspectedPanel].where((v) => v).length;
  String get objective {
    if (finished) return 'A próxima parte da história começa aqui.';
    if (!metHelena) return 'Encontre Helena perto da mercearia.';
    if (!readNews) return 'Confira o boletim na televisão da mercearia.';
    if (!inspectedPanel) return 'Compare o horário no quadro elétrico.';
    return 'Chegue à passagem leste. Abra espaço se precisar.';
  }

  List<JournalEntry> get entries => [
    const JournalEntry(
      'arrival',
      '01:58 · Santa Aurora',
      'Helena pediu que eu viesse antes das duas. A torre continua acesa.',
      'OBSERVAÇÃO',
    ),
    if (metHelena)
      const JournalEntry(
        'helena',
        'O aviso mudou',
        'Helena viu dois horários diferentes para a manutenção. Preciso comparar as fontes.',
        'DEPOIMENTO',
      ),
    if (readNews)
      const JournalEntry(
        'news',
        'A versão oficial',
        'O Canal 8 anunciou manutenção às 02:00. A rede continua transmitindo.',
        'OBSERVAÇÃO',
      ),
    if (inspectedPanel) ...[
      const JournalEntry(
        'panel',
        'Registro no quadro',
        'O relé foi acionado remotamente às 01:58. O horário está dois minutos adiantado.',
        'OBSERVAÇÃO',
      ),
      const JournalEntry(
        'hypothesis',
        'Uma transmissão deliberada?',
        'O sinal pode ter sido ativado antes do horário anunciado. Ainda não sei por quem.',
        'HIPÓTESE',
      ),
    ],
    if (helpedNeighbor)
      const JournalEntry(
        'neighbor',
        'Uma porta aberta',
        'Deixei uma atadura para a moradora. Helena vai acompanhá-la à passagem.',
        'CONSEQUÊNCIA',
      ),
  ];

  Map<String, dynamic> toJson() => {
    'schema_version': 1,
    'x': x,
    'y': y,
    'health': health,
    'stamina': stamina,
    'met_helena': metHelena,
    'read_news': readNews,
    'inspected_panel': inspectedPanel,
    'helped_neighbor': helpedNeighbor,
    'picked_bandage': pickedBandage,
    'finished': finished,
    'bandages': bandages,
    'choice': choice,
    'history': history.map((line) => line.toJson()).toList(),
  };

  String encode() => jsonEncode(toJson());

  static Campaign decode(String source) {
    final data = jsonDecode(source);
    if (data is! Map<String, dynamic> || data['schema_version'] != 1) {
      throw const FormatException('Este progresso pertence a outra versão.');
    }
    double number(String key, double min, double max) {
      final v = data[key];
      if (v is! num || !v.isFinite || v < min || v > max) {
        throw FormatException('Valor inválido no progresso: $key.');
      }
      return v.toDouble();
    }

    bool flag(String key) {
      if (data[key] is! bool) throw FormatException('Estado inválido: $key.');
      return data[key] as bool;
    }

    final bandages = data['bandages'];
    final lines = data['history'];
    if (bandages is! int ||
        bandages < 0 ||
        bandages > 10 ||
        data['choice'] is! String ||
        lines is! List ||
        lines.any((v) => v is! Map<String, dynamic>)) {
      throw const FormatException('Inventário ou histórico inválido.');
    }
    final result = Campaign()
      ..x = number('x', 1, 30)
      ..y = number('y', 1, 24)
      ..health = number('health', 0, 100)
      ..stamina = number('stamina', 0, 100)
      ..metHelena = flag('met_helena')
      ..readNews = flag('read_news')
      ..inspectedPanel = flag('inspected_panel')
      ..helpedNeighbor = flag('helped_neighbor')
      ..pickedBandage = flag('picked_bandage')
      ..finished = flag('finished')
      ..bandages = bandages
      ..choice = data['choice'] as String;
    result.history.addAll(
      lines.map((v) => DialogueLine.fromJson(v as Map<String, dynamic>)),
    );
    if (result.history.map((line) => line.id).toSet().length !=
        result.history.length) {
      throw const FormatException('Histórico com identificações repetidas.');
    }
    if (result.finished && !result.canLeave) {
      throw const FormatException('Capítulo concluído sem suas pistas.');
    }
    return result;
  }
}
